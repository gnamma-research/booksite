GNAMMA INTELLECTUAL ATLAS — OFFLINE REVISION 7
October 2026. Extract the ZIP and open:
    research/intellectual-atlas/index.html
The interactive SVG and scholarly records work locally without a server in
modern browsers allowing local scripts. If a browser blocks file:// scripts,
run: python -m http.server 8123 from the extraction folder and open
http://localhost:8123/research/intellectual-atlas/

Contents: source-critical PDF, current canonical JSON and interactive map;
standalone Neoplatonism critical dossier and Tahdhib overview.
Earlier edition PDFs/ZIPs on the web are NOT included in this archive.
External scholarly hyperlinks require internet access. Sources belong to
their respective authors/publishers. No source books/manuscript scans included.
