TEXTS IN TIME — INTEGRATED CHRONOLOGY, REVISION 2
28 October 2026

OPEN THE INTERACTIVE VERSION
Open index.html in a modern browser. Its records and interface work offline;
external scholarly source links open only when selected. This package updates
the diagram and the proposed interface. A public website has not been deployed.

WHAT CHANGED IN THIS REVISION
Empires and political periods form a compact header immediately above one shared
calendar axis. Historical event labels are interleaved with the scholarly works;
vertical event rules or interval bands continue through that same work field.
Texts from different traditions now occupy a shared compact field, distinguished
by their established colors and family codes. There are no separate history,
events, or tradition swimlane diagrams in the main timeline.

All individual ruler and caliph reign rows and their display controls have been
removed. The Cairo Abbasid ceremonial office is also omitted from the empire
header. The displayed historical register now contains 45 political periods and
36 events. The 35 ruler records and omitted office record remain in the source
data as archival research, rather than being presented as empire bars.

Select an empire/period to emphasize its chronological span through the text
field. Select an event to emphasize its date rule or interval and open its
record. Select a work or relationship to open the scholarly evidence. These
historical highlights communicate temporal context, not a new causal claim or
an assertion that every contemporaneous work belongs to a selected empire.

COMPANION PDFS, DELIVERED SEPARATELY
Islamic_Timeline_Overview.pdf — 15 pages: overview, eight chronological
  enlargements, methods, legend and revised website recommendations.
Islamic_Intellectual_Timeline.pdf — 204 pages: full network and complete
  scholarly records, historical sources, relationship evidence and critical
  qualifications. The overall diagram is page 4; enlargements are pages 5–12.

Large diagram sheets are vector pages intended for PDF zoom. The complete
master retains all entries and connections, including the undated context rail.

RESEARCH PRESERVED
295 original entries, 286 textual relationships and 282 original source records
are unchanged. The earlier 37 critical-audit entries, 98 dispositions of older
arrows, notes and contextual qualifications are preserved. History adds 69
source records; records can share URLs and are not necessarily independent
sources. The PDF includes four official implementation/accessibility references.

Author profiles group the recorded author labels and life-date wording. They
are not a new critical authority file identifying every distinct individual.

The political periods provide selected context for the corpus's regions. Their
bars have differing scopes: empire, dynasty, state, caliphal period or explicitly
labelled modern context. They do not represent borders or uniform sovereignty.
Labels in the diagram may be shortened; the original wording and source notes
remain available in detail records.

DATE SEMANTICS
All original date_start, date_end, date_status, date_label and date_note fields
are retained. The added temporal object controls plotting without inventing
precision. Its anchor is a layout position, never a new composition date.

Exact dates use a point; ranges or stages use bands; upper bounds retain an open
indication toward earlier time; publication witnesses have a distinct mark.
152 records have upper bounds. A range centre positions the label without
asserting a midpoint composition date. Three undated contextual entries remain
off the numerical axis. Original AH and SH wording is retained alongside the
common CE plotting scale. Modern spans ending numerically at 2026 use a chart
cutoff, not an asserted historical endpoint. Interrupted regimes retain segments.

INTERFACE AND WEBSITE INTEGRATION
The shared record system still supplies Timeline, Relationships, Catalogue and
Evidence & audit. The timeline itself now integrates history and scholarship.
Relationship view is an alternative way to read a selected work's sources and
reception; it does not claim a proportional chronological x-axis.

The conversation preview starts around Sharh al-Mawaqif and its immediate
connections, with the detail drawer closed to give the diagram full width.
Click any work to open it. Searches tolerate omitted transliteration diacritics.
Filters, the time window, connection expansion and URL state remain available.

Use stable work, relationship and source IDs throughout the eventual site.
The same canonical register should drive graphical marks, evidence panels,
record pages, the text reader and PDF exports. A dedicated atlas route can
serve these data as static assets; no database is needed simply to read them.
Permanent work-page routing and any reading lists/annotations should follow
the existing site's publishing and persistence decisions.

Do not make essential evidence hover-only. Preserve the textual catalogue and
relationship list as alternatives to selecting small marks. On a phone the
record panel reflows; on desktop it sits beside the diagram. Further interface
recommendations are in timeline/interactive_design_notes.txt.

REBUILD
Python 3, ReportLab and Pillow are required for the PDF. Pillow needs RAQM
support for shaped Arabic titles. DejaVu fonts are used; set KALAM_FONT_DIR if
not installed at /usr/share/fonts/truetype/dejavu. The shared renderer also has a
matplotlib font fallback. Optional validation uses PyMuPDF (fitz).

Run from the package root:
  python timeline/build_data.py
  python timeline/build_pdf.py
  python timeline/build_interactive.py

Outputs are written to output/timeline/. The interactive builder also creates
an in-conversation fragment in the project root. That response-only fragment is
not included in this archive. To refresh index.html, copy the standalone output
from output/timeline/Islamic_Intellectual_Timeline.html.

The shared build_kalam_atlas*.py modules supply typography and reference-register
renderers. Their older standalone entry points are not the build commands for
this revision. The integrated PDF does not require Graphviz.

MAIN FILES
research_v2/merged.json — unchanged underlying intellectual register.
timeline/history_early.json and history_late.json — sourced historical inputs.
timeline/integrated_display.json — presentation policy and short labels.
timeline/timeline_data.json — combined register used by the interface.
timeline/build_data.py — merges and conservatively normalizes dates.
timeline/integrated_geometry.py — shared-field PDF layout geometry.
timeline/build_pdf.py — full and overview PDF generation.
timeline/interactive_template.html — interactive application source.
timeline/build_interactive.py — creates standalone and conversation variants.
timeline/validate_revision.py — research, display-policy and PDF-link checks.
validation/ — build counts and current validation reports.

Validation checks that original records and relationships are preserved, all
source references resolve, no ruler rows are drawn, the master includes all
295 entries and 286 connections, all 81 displayed historical records resolve,
and PDF text and internal links stay within valid bounds/destinations.
Browser checks cover selection, historical highlights, evidence, source
registers, navigation state and responsive layouts. These are artifact checks;
they do not remove the historical uncertainties retained in the source notes.

No third-party source books or manuscript scans are bundled. Bibliographical
records, source links and paraphrased research notes are supplied for review.
