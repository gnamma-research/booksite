"""Critical atlas v2: explicit reception networks, summaries, detailed plates, evidence."""
from pathlib import Path
import json, math, html, os, subprocess, re, copy
from collections import defaultdict, Counter
import build_kalam_atlas as b
from reportlab.lib.pagesizes import A4,A3,A2,A1,A0,landscape
from reportlab.lib.colors import HexColor,white
from reportlab.pdfbase import pdfmetrics
ROOT=Path(__file__).resolve().parent
TMP=ROOT/'tmp/pdfs_v2';GR=TMP/'graphs';OUT=ROOT/'output/pdf/revised'
for p in [TMP,GR,OUT]:p.mkdir(parents=True,exist_ok=True)
b.TMP=TMP;b.GR=GR
PALETTE={
 'ancient':('#EFF0F4','#414653','GRC','Greek and late antique'),
 'translation':('#F7EDD7','#805A12','TRN','Translation / adaptation'),
 'christian':('#F1E9F4','#793876','CHR','Christian authored works'),
 'jewish':('#F4EDE7','#80543E','JUD','Jewish Arabic thought'),
 'falsafa':('#E4F2F8','#006080','FAL','Arabic Aristotelian philosophy'),
 'avicennan':('#E4EFFA','#006CB0','AVI','Avicennan reception'),
 'ishraqi':('#FFE3B5','#A14B00','ISH','Illuminationist reception'),
 'akbarian':('#FCE7F1','#B02A70','AKB','Akbarian reception'),
 'mutazili':('#FAE7E8','#A12E3C','MUT','Muʿtazilī networks'),
 'sunni':('#E4F3ED','#087751','SUN','Sunni kalām networks'),
 'imami':('#EBE8FA','#51439D','IMM','Imami kalām / synthesis'),
 'sadrian':('#EAF4C8','#596F00','SAD','Ṣadrian reception'),
 'critical':('#DEE7ED','#394B5A','CRT','Distinct Iranian critics'),
 'context':('#EDF0F1','#52606A','CTX','Context / claims / hypotheses')}
# Shape / line pattern plus printed labels, never color alone.
RELS={
 'commentary':('#283F55',[],1.15,'C','commentary'),
 'gloss':('#283F55',[],1.0,'G','gloss'),
 'translation_adaptation':('#805A12',[],1.4,'T','translation / adaptation'),
 'textual_use':('#285F82',[6,3],1.05,'U','citation / use / reworking'),
 'author_reference':('#476775',[2,3],1.05,'A','explicit author reference'),
 'critique':('#A12E3C',[],1.3,'X','critical engagement'),
 'reported_doctrine':('#5E6470',[3,2],1.0,'R','reported teaching'),
 'reported_source':('#5E6470',[3,2],1.0,'S','named-source testimony'),
 'exchange':('#705B90',[6,2],1.1,'E','multi-round exchange'),
 'broad_influence':('#57656B',[1.2,3],1.0,'B','qualified broader connection'),
 'hypothesis':('#79858B',[7,3,1,3],1.0,'?','proposed transmission'),
 'claimed_lineage':('#A45F00',[7,3,1,3],1.0,'L','claimed ancient lineage')}
b.PALETTE={k:(v[0],v[1]) for k,v in PALETTE.items()};b.PALETTE['modern']=b.PALETTE['context']
esc=b.esc;para=b.para;pheight=b.pheight;lines_for=b.lines_for;drawlines=b.drawlines;refs=b.source_refs
INK=b.INK;NAVY=b.NAVY;MUTED=b.MUTED;RULE=b.RULE

class Doc(b.Doc):
 def __init__(self,path,nav=False):
  super().__init__(path);self.nav=nav;self.work_pages={};self.edge_pages={}
  self.c.setTitle('Philosophy, Kalām and Sufi Metaphysics: Critical Genealogies, revised atlas')
  self.c.setSubject('Greek, Syriac and Arabic transmission; Avicennan, Illuminationist, Akbarian, Sunni and Imami networks')
 def new(self,title=None,size=A4,key=None,section=None):
  if self.p:self.c.showPage()
  self.p+=1;self.size=size;self.c.setPageSize(size);w,h=size
  self.c.setFillColor(HexColor(b.PAPER));self.c.rect(0,0,w,h,fill=1,stroke=0)
  if key:
   self.c.bookmarkPage(key);self.c.addOutlineEntry(title or 'Cover',key,0,False);self.toc.append((title,key,self.p))
  if title:
   self.c.setFillColor(HexColor(NAVY));self.c.setFont('DB',8.5);self.c.drawString(36,h-28,'PHILOSOPHY · KALĀM · SUFI METAPHYSICS / REVISION 2')
   title_size=20 if w<900 else 26
   hh=para(self.c,esc(title),36,h-47,w-72,title_size,color=NAVY,bold=True,leading=title_size*1.15)
   self.c.setStrokeColor(HexColor(RULE));self.c.line(36,39,w-36,39)
   self.c.setFont('D',7.4);self.c.setFillColor(HexColor(MUTED));self.c.drawString(36,26,section or '28 October 2026 · Work dates, bounds and uncertainties are distinguished in the catalogue.')
   self.c.drawRightString(w-36,26,str(self.p))
   if self.nav:
    self.c.setFont('DB',7.5);self.c.drawRightString(w-36,h-28,'INDEX');self.c.linkRect('','navigation',(w-80,h-37,w-34,h-18),thickness=0)
   return h-47-hh-16
  return h-85

def card(n,compact=False):
 w=225 if compact else 250
 tsize=10.8 if compact else 11.5
 title=lines_for(n['title'],w-24,'DB',tsize)
 author=lines_for(n['author'],w-24,'D',9.5)
 date=lines_for(n['date_label'],w-24,'DB',9.5)
 stream=PALETTE.get(n['tradition'],PALETTE['context'])[2]
 context=[stream+' · '+n.get('region','').split(';')[0]]
 tags=n.get('map_tags',[])
 if tags:context.append(' / '.join(tags))
 context=[l for txt in context for l in lines_for(txt,w-24,'D',7.8)]
 h=34+len(title)*14+len(author)*12+len(date)*12+len(context)*10+18
 return dict(w=w,h=h,title=title,author=author,date=date,context=context,compact=compact)

def make_dot(spec,ni,edges):
 ids=list(dict.fromkeys(spec['nodes']));selected=set(ids)
 es=spec.get('edges')
 if es is None:es=[e for e in edges if e['source'] in selected and e['target'] in selected]
 cards={i:card(ni[i],spec.get('compact',False)) for i in ids}
 rankdir=spec.get('direction','TB');pack='pack=true, packmode="array3", ' if not (spec.get('overview') or spec.get('master') or spec.get('rows')) else ''
 out=['digraph G {',f'graph [rankdir={rankdir}, {pack}bgcolor="transparent", splines=spline, overlap=false, nodesep="0.32", ranksep="0.65", outputorder=edgesfirst, newrank=true,pad="0.10"];',
      'node [shape=box, fixedsize=true,label="",style="rounded"];','edge [fontsize=8,arrowsize=.7];']
 for i in ids:
  cr=cards[i];out.append(f'"{i}" [width={cr["w"]/72:.4f},height={cr["h"]/72:.4f}];')
 if spec.get('rows'):
  for j,row in enumerate(spec['rows']):
   row=[i for i in row if i in selected]
   out.append(f'"tier{j}" [width=.01,height=.01,shape=point,style=invis];')
   out.append('{rank=same; "tier'+str(j)+'"; '+'; '.join('"'+i+'"' for i in row)+';}')
   for a,bb in zip(row,row[1:]):out.append(f'"{a}" -> "{bb}" [style=invis,weight=100];')
  for j in range(len(spec['rows'])-1):out.append(f'"tier{j}" -> "tier{j+1}" [style=invis,weight=200];')
 if spec.get('master'):
  buckets=defaultdict(list)
  for i in ids:
   date=ni[i].get('date_end')
   date=2000 if date is None else date
   step=200 if date<600 else (100 if date<1100 else 50)
   buckets[(date//step)*step].append(i)
  prev=None
  for j,(date,row) in enumerate(sorted(buckets.items())):
   # At most eight cards per historical row; rows are a display aid, not exact timeline.
   for z in range(0,len(row),8):
    key=f'era{j}_{z}';out.append(f'"{key}" [width=.01,height=.01,shape=point,style=invis];')
    out.append('{rank=same; "'+key+'"; '+'; '.join('"'+i+'"' for i in row[z:z+8])+';}')
    if prev:out.append(f'"{prev}" -> "{key}" [style=invis,weight=200];')
    prev=key
 for e in es:
  col,dash,pw,tag,lab=RELS.get(e['relation'],RELS['broad_influence'])
  uncertain=e.get('confidence') in ['qualified','hypothesis','proposed','proposed specific channel','contested'] or e['relation'] in ['hypothesis','claimed_lineage']
  style='dotted' if uncertain else ('dashed' if dash else 'solid')
  arrow='empty' if uncertain else 'normal'
  more=',dir=both,arrowtail=normal' if e['relation']=='exchange' else ''
  out.append(f'"{e["source"]}" -> "{e["target"]}" [id="{e["id"]}",color="{col}",style={style},penwidth={pw},arrowhead={arrow},constraint={"false" if spec.get("rows") or spec.get("master") else "true"}{more}];')
 out.append('}')
 (GR/(spec['id']+'.dot')).write_text('\n'.join(out))
 return dict(cards=cards,edges=es,nodeids=ids)

def draw_graph(c,name,meta,ni,box,links=True,edge_labels=True,work_link_prefix='work_'):
 geo=json.loads((GR/(name+'.json')).read_text());bb=list(map(float,geo['bb'].split(',')));gw,gh=bb[2],bb[3]
 x,y,w,h=box;scale=min(w/gw,h/gh);ox=x+(w-gw*scale)/2;oy=y+(h-gh*scale)/2
 c.saveState();c.translate(ox,oy);c.scale(scale,scale)
 edge_lookup={e['id']:e for e in meta['edges']};occupied=[];paths=[]
 for o in geo.get('objects',[]):
  if o['name'] in meta['cards']:
   cr=meta['cards'][o['name']];cx,cy=map(float,o['pos'].split(','));occupied.append((cx-cr['w']/2-5,cy-cr['h']/2-5,cx+cr['w']/2+5,cy+cr['h']/2+5))
 for ee in geo.get('edges',[]):
  eid=ee.get('id')
  if eid not in edge_lookup:continue
  item=edge_lookup[eid];col,dash,pw,tag,_=RELS.get(item['relation'],RELS['broad_influence'])
  c.saveState();c.setStrokeColor(HexColor(col));c.setFillColor(HexColor(col));c.setLineWidth(pw)
  b.draw_path_ops(c,ee.get('_draw_',[]));c.setDash();b.draw_path_ops(c,ee.get('_hdraw_',[]));b.draw_path_ops(c,ee.get('_tdraw_',[]))
  if edge_labels:
   for op in ee.get('_draw_',[]):
    if op['op'] in ['b','B']:paths.append((eid,tag,col,op['points']))
  c.restoreState()
 for o in geo.get('objects',[]):
  i=o['name']
  if i not in meta['cards']:continue
  n=ni[i];cr=meta['cards'][i];cw,ch=cr['w'],cr['h'];cx,cy=map(float,o['pos'].split(','));left=cx-cw/2;bottom=cy-ch/2
  fill,border,stream,_=PALETTE.get(n['tradition'],PALETTE['context'])
  c.setFillColor(HexColor(fill));c.setStrokeColor(HexColor(border));c.setLineWidth(1.2)
  typ=n.get('node_type','work');c.setDash([4,3] if typ!='work' else [])
  radius=15 if typ!='work' else 6;c.roundRect(left,bottom,cw,ch,radius,fill=1,stroke=1);c.setDash()
  c.setFillColor(HexColor(border));c.roundRect(left,bottom+ch-22,cw,22,radius,fill=1,stroke=0);c.rect(left,bottom+ch-22,cw,10,fill=1,stroke=0)
  c.setFillColor(white);c.setFont('DB',8.2);c.drawString(left+10,bottom+ch-14,n['code'])
  kind='GLOSS SERIES' if i in ['dawwani_tajrid','dashtaki_tajrid'] else (typ.upper() if typ!='work' else n['kind'].upper())
  if len(kind)>28:kind=kind[:25]+'…'
  c.drawRightString(left+cw-10,bottom+ch-14,stream+' · '+kind)
  yy=bottom+ch-38;yy=drawlines(c,cr['title'],left+12,yy,10.8 if cr['compact'] else 11.5,'DB',14)
  yy-=4;yy=drawlines(c,cr['author'],left+12,yy,9.5,'D',12)
  yy-=4;yy=drawlines(c,cr['date'],left+12,yy,9.5,'DB',12,color=border)
  yy-=4;drawlines(c,cr['context'],left+12,yy,7.8,'D',10,color=MUTED)
  if links:c.linkRect('',n.get('link',work_link_prefix+i),(left,bottom,left+cw,bottom+ch),relative=1,thickness=0)
 def hits(r):return any(r[0]<s[2] and r[2]>s[0] and r[1]<s[3] and r[3]>s[1] for s in occupied)
 for eid,tag,col,pts in paths:
  sampled=[]
  for j in range(0,len(pts)-3,3):
   a,bb,cc,dd=pts[j:j+4]
   for z in range(25):
    t=z/24;u=1-t;sampled.append((u**3*a[0]+3*u*u*t*bb[0]+3*u*t*t*cc[0]+t**3*dd[0],u**3*a[1]+3*u*u*t*bb[1]+3*u*t*t*cc[1]+t**3*dd[1]))
  if not sampled:continue
  dist=[0]
  for a,bb in zip(sampled,sampled[1:]):dist.append(dist[-1]+math.hypot(bb[0]-a[0],bb[1]-a[1]))
  label=eid.replace('_e','-')+' '+tag;size=8;tw=pdfmetrics.stringWidth(label,'DB',size);chosen=None
  for frac in [.5,.4,.6,.3,.7,.2,.8,.1,.9]:
   k=min(range(len(dist)),key=lambda j:abs(dist[j]-dist[-1]*frac));tx,ty=sampled[k]
   for dy in [5,-10,16,-21,27,-32,0]:
    rect=(tx-tw/2-3,ty+dy-3,tx+tw/2+3,ty+dy+9)
    if not hits(rect):chosen=(tx,ty+dy,rect);break
   if chosen:break
  if not chosen:
   tx,ty=sampled[len(sampled)//2];chosen=(tx,ty+5,(tx-tw/2-3,ty+2,tx+tw/2+3,ty+14))
  tx,ty,rect=chosen;occupied.append(rect);c.setFillColor(white);c.roundRect(rect[0],rect[1],rect[2]-rect[0],rect[3]-rect[1],2,fill=1,stroke=0)
  c.setFillColor(HexColor(col));c.setFont('DB',size);c.drawCentredString(tx,ty,label)
  if links:c.linkRect('',edge_lookup[eid].get('link','edge_'+eid),rect,relative=1,thickness=0)
 c.restoreState();return scale,(gw,gh)

def compact_legend(c,x,y,w,streams,relations=True):
 ss=[k for k in PALETTE if k in streams];cols=min(5,len(ss)) or 1;gap=w/cols
 for j,k in enumerate(ss):
  xx=x+(j%cols)*gap;yy=y-(j//cols)*18;fill,border,code,label=PALETTE[k]
  c.setFillColor(HexColor(fill));c.setStrokeColor(HexColor(border));c.roundRect(xx,yy-9,10,10,2,fill=1,stroke=1)
  c.setFillColor(HexColor(INK));c.setFont('DB',7.8);c.drawString(xx+15,yy-7,code)
  c.setFont('D',7.5);short=label.replace(' reception','').replace(' networks','').replace(' authored works','')
  c.drawString(xx+41,yy-7,short)
 if relations:
  yy=y-math.ceil(len(ss)/cols)*18-5
  text='C commentary · G gloss · T translation/adaptation · U use · A author reference · X critique · R report · S source testimony · E exchange · B broader link · ? hypothesis · L claimed lineage'
  para(c,esc(text),x,yy,w,7.8,leading=10)
  para(c,'Open arrowheads and dotted lines mark a qualified relation. Corpus/context boxes have dashed borders. Printed stream codes supplement color.',x,yy-26,w,7.7,color=MUTED)

def draw_plate(doc,spec,meta,ni,links=True,summary=False):
 geo=json.loads((GR/(spec['id']+'.json')).read_text());bb=list(map(float,geo['bb'].split(',')));gw,gh=bb[2:]
 base=landscape(A3) if not spec.get('overview') else landscape(A2)
 minimum=.86 if not summary else .93
 sw=max(base[0],gw*minimum+72);sh=max(base[1],gh*minimum+270)
 y=doc.new(spec['title'],(sw,sh),spec['id'] if links else None)
 h=para(doc.c,esc(spec.get('subtitle','')),36,y,sw-72,10.2)
 sc,dims=draw_graph(doc.c,spec['id'],meta,ni,(36,172,sw-72,y-h-190),links=links,edge_labels=not spec.get('master'))
 streams=set(ni[i]['tradition'] for i in spec['nodes']);compact_legend(doc.c,36,151,sw-72,streams)
 doc.audit.append(dict(plate=spec['id'],nodes=len(spec['nodes']),edges=len(meta['edges']),scale=sc,min_font_pt=round(sc*7.8,2),size_pt=[sw,sh]))
 return sc

def block_pages(doc,title,items,key,size=A4):
 def text(a):
  head=a.get('title',a.get('target','Audit finding'));body=a.get('text',a.get('issue',''))
  if a.get('recommendation'):body+=' '+a['recommendation']
  if a.get('action'):head+=' ['+a['action']+']'
  return f'<b>{esc(head)}</b><br/>{esc(b.tidy(body))}<br/>{refs(a.get("sources",[]))}'
 b.entry_flow(doc,items,lambda a,x,y,w,h:para(doc.c,text(a),x,y,w,9.5),lambda a,w:pheight(text(a),w,9.5)+21,title,key,size=size)

def cover(doc,data):
 c=doc.c;doc.new(key='cover');w,h=A4
 c.setFillColor(HexColor(NAVY));c.rect(0,h-292,w,292,fill=1,stroke=0)
 c.setFillColor(HexColor('#BFD8DC'));c.setFont('DB',9.5);c.drawString(40,h-43,'A CRITICAL RESEARCH ATLAS · REVISED 28 OCTOBER 2026')
 yy=h-98
 for line in ['Philosophy, kalām','and Sufi metaphysics']:
  c.setFont('DSB',29);c.setFillColor(white);c.drawString(40,yy,line);yy-=42
 para(c,'Dated textual genealogies, alternative continuations,<br/>documented transmission and claimed ancestries',40,h-207,w-80,12.5,color='#E7EFF0')
 yy=h-326
 counts=Counter(n.get('node_type','work') for n in data['nodes'])
 yy-=para(c,f'<b>{len(data["nodes"])} entries · {len(data["edges"])} relationships · {len(data["sources"])} source records</b><br/>{counts["work"]} work / work-series entries; {len(data["nodes"])-counts["work"]} explicitly marked corpus or context anchors.',40,yy,w-80,11)+22
 yy-=para(c,'From Pythagoras, Plato and Aristotle through late antiquity and the Arabic translation movement to Avicennan, Illuminationist, Akbarian, Sunni and Imami continuations in the modern period.',40,yy,w-80,11.5)+20
 yy-=para(c,'The earlier atlas is critically revised, not merely enlarged. Its weakest source proxies are changed, continuing traditions receive their own maps, and different kinds of uncertainty remain visible.',40,yy,w-80,11.5)+22
 c.setFillColor(HexColor('#E4F2F0'));c.roundRect(40,yy-111,w-80,111,8,fill=1,stroke=0)
 para(c,'<b>Three levels of reading</b><br/>1. Overall map of interacting traditions.<br/>2. Summary maps of the principal textual families.<br/>3. Detailed maps, dated catalogue and an evidence record for every arrow.',55,yy-15,w-110,10.5)
 para(c,'A selective historical atlas. It is not a claim that philosophy began in Greece, that every affinity is a borrowing, or that one work concludes an entire tradition.',40,55,w-80,8.2,color=MUTED)

def method_pages(doc):
 block_pages(doc,'What the revision changes',[
  dict(title='Verdict on the first atlas',text='Its strongest material was the formal commentary genealogy around Mawāqif, Maqāṣid and Tajrīd. It was not an adequate map of Islamic philosophy as a whole: Avicennan continuations, Illuminationist reception and Akbarian metaphysics were seriously underrepresented. The overall visual story therefore leaned too heavily toward kalām and Ṣadrā.'),
  dict(title='A network, not a single family tree',text='Authors comment on several traditions, criticize their own teachers, and reuse arguments from opponents. A citation establishes contact; it does not establish agreement, exclusive dependence, or institutional dominance. Some summary connections collect several exact cases; their evidence is listed separately.'),
  dict(title='What has actually been checked',text='The audit reconsiders all 98 first-edition edges for their evidentiary meaning, retains sound bibliographical relationships, and revisits the most consequential proxy and classification claims. It does not claim a fresh manuscript collation of every text. Evidence labels distinguish primary passages, catalogue identifications, specialist studies and explicit research hypotheses.'),
  dict(title='Dates and survival',text='A dated completion is different from a death bound, dedication bound, probable period, revision or publication witness. Lost and fragmentary works remain visible as such. Early authors with no securely surviving authored book are corpus/context anchors, not fictitious titles.'),
  dict(title='Continuing limits',text='The selection is broad but finite. It does not exhaust logic, medicine, all Ottoman or South Asian manuscripts, every Sufi order, Ismaili and Zaydi philosophy, or all modern Arabic and Persian thought. An isolated node means that a particular parent text has not been established here, not that the work had no intellectual background.')
 ],'revision_method')
 y=doc.new('Two independent questions about every arrow',A4,'relation_legend');w,h=A4;c=doc.c
 y-=para(c,'<b>What relation does the later text have to the earlier one?</b> The letter beside each arrow records its type. The evidence register then states why the connection is warranted.',36,y,w-72,10.2)+19
 for key,(col,dash,pw,tag,label) in RELS.items():
  c.setStrokeColor(HexColor(col));c.setLineWidth(pw);c.setDash(dash);c.line(38,y-7,72,y-7);c.setDash()
  y-=para(c,f'<b>{tag} · {esc(label)}</b>',85,y,w-121,9.6)+8
 y-=12
 y-=para(c,'<b>How strong and specific is the evidence?</b><br/>A primary quotation, a title identifying a base text, a modern comparison of passages, and a proposed historical channel are different supports. The line type does not by itself answer that second question. Qualified links have open arrowheads and dotted lines, with the reason stated in the register.',36,y,w-72,10)+17
 para(c,'For a critical commentary, X may be the most informative label even though the work is also formally a commentary. A cited passage has a limited scope: it cannot establish everything about the later author’s system.',36,y,w-72,9.6)
 y=doc.new('Colors, labels and overlapping commitments',A4,'stream_legend')
 y-=para(c,'The color identifies the principal <b>textual reception network used on this map</b>. It is not an exclusive confessional label and does not certify assent to every doctrine. Every box repeats a short stream code.',36,y,w-72,10.3)+19
 for k,(fill,col,code,label) in PALETTE.items():
  c.setFillColor(HexColor(fill));c.setStrokeColor(HexColor(col));c.roundRect(38,y-16,27,17,3,fill=1,stroke=1)
  y-=para(c,f'<b>{code}</b> · {esc(label)}',78,y,w-114,9.6)+10
 y-=8
 para(c,'<b>Example:</b> a Jilveh commentary on the Shifāʾ belongs to AVI; his gloss on the Asfār is a SAD reception text with critical Avicennan commitments. A Sunni gloss on Ṭūsī belongs to a shared Tajrīd discussion. Regional setting, genre and doctrinal qualification are stated separately in the catalogue.',36,y,w-72,9.5)

def catalogue(doc,data,ni):
 c=doc.c
 def wt(n):
  stream=PALETTE.get(n['tradition'],PALETTE['context'])[3]
  extras=''
  if n.get('tags'):extras+='<br/><b>Additional tags:</b> '+esc(' / '.join(n['tags']))+'.'
  if n.get('confession'):extras+='<br/><b>Confessional context:</b> '+esc(n['confession'])+'.'
  if n.get('size'):extras+='<br/><b>Scale / edition:</b> '+esc(n['size'])
  return f'<b>Work / context date:</b> {esc(n["date_label"])}. {esc(n.get("date_note",""))}<br/><b>Network:</b> {esc(stream)}. <b>Setting:</b> {esc(n.get("region",""))}.<br/><b>Type:</b> {esc(n["kind"])}. {esc(n.get("note",""))}{extras}<br/>{refs(n["sources"])}'
 def wh(n,cw):return pheight(f'<b>{n["code"]} · {esc(n["title"])}</b>',cw,11.7)+pheight(f'{esc(n["author"])} ({esc(n["author_dates"])})',cw,9.4)+pheight(wt(n),cw,8.9)+34+(21 if n.get('title_ar') else 0)
 def wr(n,x,y,cw,hh):
  c.bookmarkHorizontal('work_'+n['id'],0,y);doc.work_pages[n['id']]=doc.p;col=PALETTE.get(n['tradition'],PALETTE['context'])[1]
  y-=para(c,f'<b>{n["code"]} · {esc(n["title"])}</b>',x,y,cw,11.7,color=col)+3
  y-=para(c,f'{esc(n["author"])} ({esc(n["author_dates"])})',x,y,cw,9.4)+6
  ar=b.arabic_title(n)
  if ar:
   path,iw,ih=ar;dh=16;dw=min(cw,iw*dh/ih);dh=dw*ih/iw;c.drawImage(str(path),x+cw-dw,y-dh,width=dw,height=dh,mask='auto');y-=dh+5
  used=para(c,wt(n),x,y,cw,8.9);c.setStrokeColor(HexColor(RULE));c.line(x,y-used-10,x+cw,y-used-10)
 b.entry_flow(doc,data['nodes'],wr,wh,'Dated catalogue of works and anchors','catalogue',size=A4)

def evidence_register(doc,data,ni):
 c=doc.c
 def et(e):
  rel=RELS.get(e['relation'],RELS['broad_influence']);a=ni[e['source']];bb=ni[e['target']]
  return f'<b>{e["id"].replace("_e","-")} · {rel[3]} · {esc(rel[4])}</b><br/><b>Support:</b> {esc(e.get("evidence_kind",""))}; {esc(e["confidence"])}.<br/><link href="#work_{a["id"]}" color="#006CB0"><b>{a["code"]}</b> {esc(a["title"])}</link><br/>→ <link href="#work_{bb["id"]}" color="#006CB0"><b>{bb["code"]}</b> {esc(bb["title"])}</link><br/>{esc(e["evidence"])}<br/>{refs(e["sources"])}'
 def er(e,x,y,w,h):
  c.bookmarkHorizontal('edge_'+e['id'],0,y);doc.edge_pages[e['id']]=doc.p;used=para(c,et(e),x,y,w,8.6);c.setStrokeColor(HexColor(RULE));c.line(x,y-used-10,x+w,y-used-10)
 b.entry_flow(doc,data['edges'],er,lambda e,w:pheight(et(e),w,8.6)+20,'Evidence for detailed-map relationships','relationships',cols=2,size=landscape(A4))

def source_register(doc,data):
 def st(s):
  url=s.get('url','');note=s.get('note',s.get('notes',''))
  if isinstance(note,list):note=' '.join(note)
  return f'<b>{s["id"]} · {esc(s.get("author",""))}</b><br/>{esc(s["title"])}<br/>{esc(s.get("type","source"))} · {esc(note)}<br/><link href="{html.escape(url,quote=True)}" color="#006CB0">Open source</link>'
 def sr(s,x,y,w,h):
  doc.c.bookmarkHorizontal('src_'+s['id'],0,y);used=para(doc.c,st(s),x,y,w,8.6);doc.c.setStrokeColor(HexColor(RULE));doc.c.line(x,y-used-10,x+w,y-used-10)
 b.entry_flow(doc,data['sources'],sr,lambda s,w:pheight(st(s),w,8.6)+20,'Sources and bibliographical notes','sources',cols=2,size=landscape(A4))

def prior_audit(doc,data,ni):
 def txt(e):
  a=ni[e['source']];bb=ni[e['target']]
  return f'<b>{e["id"].replace("_e","-")}</b> · {a["code"]} → {bb["code"]}<br/>{esc(e["status"])}<br/>{refs(e["sources"])}'
 b.entry_flow(doc,data['prior_edge_audit'],lambda e,x,y,w,h:para(doc.c,txt(e),x,y,w,8.5),lambda e,w:pheight(txt(e),w,8.5)+16,'Disposition of all first-edition arrows','old_edge_audit',cols=2,size=landscape(A4))

def navigation(doc,data,ni):
 y=doc.new('Navigation index',A4,'navigation');w,h=A4
 for title,key,pg in list(doc.toc)[:-1]:
  txt=f'<link href="#{key}" color="#006CB0">{esc(title or "Cover")}</link>';hh=pheight(txt,w-107,9.6)
  if y-hh<60:y=doc.new('Navigation index · continued')
  para(doc.c,txt,36,y,w-107,9.6);doc.c.setFont('DB',9.5);doc.c.setFillColor(HexColor(INK));doc.c.drawRightString(w-36,y-10,str(pg));y-=hh+9
 # Stable-ID index supplies quick page lookup independently of PDF link support.
 rows=sorted(data['nodes'],key=lambda n:n['code'])
 def txt(n):return f'<link href="#work_{n["id"]}" color="#006CB0"><b>{n["code"]}</b> {esc(n["title"])}</link> · p.{doc.work_pages[n["id"]]}'
 b.entry_flow(doc,rows,lambda n,x,y,w,h:para(doc.c,txt(n),x,y,w,8.5),lambda n,w:pheight(txt(n),w,8.5)+8,'Stable work-ID index','work_index',cols=2,size=landscape(A4))

def main():
 data=json.loads((ROOT/'research_v2/merged.json').read_text());ni={n['id']:n for n in data['nodes']}
 config=json.loads((ROOT/'research_v2/maps.json').read_text());details=config['details'];summaries=config['summaries'];overall=config['overall']
 # Every displayed node/edge has a real register entry; supplementary plates prevent silent orphaning.
 for spec in details+summaries:
  spec['nodes']=list(dict.fromkeys(i for i in spec['nodes'] if i in ni))
 covered=set(i for s in details for i in s['nodes']);uncovered=[i for i in ni if i not in covered]
 if uncovered:
  for z in range(0,len(uncovered),12):details.append(dict(id=f'd_context_{z//12+1}',title=f'Additional contextual works {z//12+1}',subtitle='Entries retained for context; no undemonstrated parent-text connection is implied.',nodes=uncovered[z:z+12]))
 covered_edges={e['id'] for e in data['edges'] if any(e['source'] in s['nodes'] and e['target'] in s['nodes'] for s in details)}
 remaining=[e for e in data['edges'] if e['id'] not in covered_edges]
 groups=[];current=[];members=set()
 for e in sorted(remaining,key=lambda e:e['target']):
  new=members|{e['source'],e['target']}
  if len(new)>15 and current:groups.append((current,members));current=[];members=set();new={e['source'],e['target']}
  current.append(e);members=new
 if current:groups.append((current,members))
 for z,(edges,members) in enumerate(groups,1):details.append(dict(id=f'd_cross_{z}',title=f'Cross-tradition reception details {z}',subtitle='Additional documented connections whose endpoints lie in different principal families.',nodes=sorted(members),edges=edges))
 master=dict(id='full_network',title='Complete detailed network',subtitle='Large vector sheet. Use the summary maps for orientation and the atlas for evidence.',nodes=list(ni),master=True,compact=True)
 # Overview uses abstract family nodes and only explicitly documented examples.
 oni={n['id']:n for n in overall['group_nodes']};overall['nodes']=list(oni);overall['overview']=True;overall['compact']=True
 metas={}
 for spec in details+summaries+[master]:metas[spec['id']]=make_dot(spec,ni,data['edges'])
 metas[overall['id']]=make_dot(overall,oni,overall['edges'])
 subprocess.run([os.environ.get('CODEX_PRIMARY_RUNTIME_NODE','node'),str(ROOT/'render_graphs.mjs'),str(GR)],check=True,stdout=subprocess.PIPE)
 doc=Doc(OUT/'Kalam_Intellectual_Genealogies_Atlas.pdf',nav=True)
 cover(doc,data);method_pages(doc)
 block_pages(doc,'Critical audit: corrections and qualifications',data['audit'],'critical_audit')
 draw_plate(doc,overall,metas[overall['id']],oni,links=True,summary=True)
 # Overview evidence register is short and connects group-level arrows to exact evidence.
 oitems=[]
 for e in overall['edges']:
  doc.c.bookmarkPage('overview_edge_'+e['id']) if False else None
  oitems.append(e)
 def ot(e):
  underlying=e.get('underlying',[])
  ll=' '.join(f'<link href="#edge_{x}" color="#006CB0">{x.replace("_e","-")}</link>' for x in underlying)
  return f'<b>{e["id"]} · {esc(e["label"])}</b><br/>{esc(e["evidence"])}<br/>{ll} {refs(e.get("sources",[]))}'
 def ore(e,x,y,w,h):doc.c.bookmarkHorizontal('overview_edge_'+e['id'],0,y);para(doc.c,ot(e),x,y,w,8.8)
 b.entry_flow(doc,oitems,ore,lambda e,w:pheight(ot(e),w,8.8)+16,'What the overall arrows summarize','overview_evidence',cols=2,size=landscape(A4))
 for spec in summaries:draw_plate(doc,spec,metas[spec['id']],ni,links=True,summary=True)
 for spec in details:draw_plate(doc,spec,metas[spec['id']],ni,links=True)
 catalogue(doc,data,ni);evidence_register(doc,data,ni);source_register(doc,data);prior_audit(doc,data,ni)
 block_pages(doc,'Further research qualifications',data['notes'],'qualifications')
 navigation(doc,data,ni);doc.save()

 summary=Doc(OUT/'Kalam_Genealogies_Summary_Maps.pdf')
 y=summary.new('Summary maps: a guide to the revised atlas',A4,'summary_guide');w,h=A4
 for head,body in [
  ('Start with the overall map','It groups the principal traditions. An arrow summarizes a particular documented contact, not the ancestry of every work in both groups.'),
  ('Then follow a textual family','The following summary maps select representative works. They retain actual work dates and authors, while the complete detailed plates are in the revised atlas.'),
  ('Read the edge letters','C commentary; G gloss; T translation/adaptation; U use; A explicit author reference; X critique; R reported doctrine; S source testimony; E exchange; B broader connection; ? hypothesis; L claimed lineage.'),
  ('Use the stable identifiers','W numbers identify catalogue entries. Arrow IDs identify the evidence register in the companion atlas. This separate summary pack intentionally has no internal links to pages it does not contain.'),
  ('Color identifies a reception network','AVI is Avicennan, ISH Illuminationist, AKB Akbarian, SAD Ṣadrian, SUN Sunni kalām, IMM Imami, MUT Muʿtazilī. Additional colors identify Greek, translated, Christian and Jewish works. Commentary is not assent; one author may occur in several networks.'),
  ('The complete atlas','The revised companion includes the critique of the first edition, every detailed map, full dated catalogue, evidence and sources. The map is selective and source-aware; it is not a complete inventory of all intellectual life.')]:
  y-=para(summary.c,esc(head),36,y,w-72,12,bold=True)+4;y-=para(summary.c,esc(body),36,y,w-72,10)+19
 for spec in [overall]+summaries:draw_plate(summary,spec,metas[spec['id']],oni if spec is overall else ni,links=False,summary=True)
 summary.save()

 m=Doc(OUT/'Kalam_Genealogies_Master_Map.pdf');geo=json.loads((GR/'full_network.json').read_text());bb=list(map(float,geo['bb'].split(',')));mw=max(landscape(A0)[0],bb[2]*.80+100);mh=max(landscape(A0)[1],bb[3]*.80+265)
 y=m.new('Complete detailed network: use with the critical atlas',(mw,mh),'full_map');para(m.c,f'{len(ni)} entries · {len(data["edges"])} relationships. Large vector sheet; the separate summary maps provide orientation. Historical arrangement is approximate, not a proportional timeline.',36,y,mw-72,14)
 sc,_=draw_graph(m.c,'full_network',metas['full_network'],ni,(40,175,mw-80,mh-310),links=False,edge_labels=False);compact_legend(m.c,40,151,min(mw-80,2100),set(n['tradition'] for n in ni.values()));m.save()
 audit=dict(entries=len(ni),works=sum(n['node_type']=='work' for n in ni.values()),relationships=len(data['edges']),sources=len(data['sources']),atlas_pages=doc.p,summary_pages=summary.p,summary_maps=1+len(summaries),detailed_maps=len(details),old_edges_reviewed=len(data['prior_edge_audit']),plates=doc.audit,toc=doc.toc,work_pages=doc.work_pages,edge_pages=doc.edge_pages,master_size_pt=[mw,mh],master_min_font=round(sc*7.8,2))
 (TMP/'build_audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2));(ROOT/'research_v2/final_map_membership.json').write_text(json.dumps(dict(details=details,summaries=summaries,overall=overall),ensure_ascii=False,indent=2))
 print(json.dumps({k:v for k,v in audit.items() if k not in ['plates','toc','work_pages','edge_pages']},indent=2))

if __name__=='__main__':main()
