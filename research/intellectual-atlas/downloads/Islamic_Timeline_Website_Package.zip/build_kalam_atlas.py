"""Build the dated text atlas from the independently sourced research registers.
Graphviz (Viz.js) supplies geometry only; ReportLab draws embedded-font vectors.
"""
from pathlib import Path
import json, math, re, html, textwrap, subprocess, os, sys
from collections import defaultdict
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor, Color, white
from reportlab.lib.pagesizes import A4, A3, A0, landscape
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Paragraph
from reportlab.lib.styles import ParagraphStyle
from PIL import Image, ImageDraw, ImageFont

ROOT=Path(__file__).resolve().parent
TMP=ROOT/'tmp/pdfs'; GR=TMP/'graphs'; OUT=ROOT/'output/pdf'
for p in [TMP,GR,OUT]: p.mkdir(parents=True,exist_ok=True)
FONTS=Path(os.environ.get('KALAM_FONT_DIR','/usr/share/fonts/truetype/dejavu'))
for name,fn in [('D','DejaVuSans.ttf'),('DB','DejaVuSans-Bold.ttf'),('DI','DejaVuSans-Oblique.ttf'),('DS','DejaVuSerif.ttf'),('DSB','DejaVuSerif-Bold.ttf')]:
    fp=FONTS/fn
    if not fp.exists():
        import importlib.util
        mod=importlib.util.find_spec('matplotlib')
        fp=Path(mod.submodule_search_locations[0])/'mpl-data/fonts/ttf'/fn
    pdfmetrics.registerFont(TTFont(name,str(fp)))
pdfmetrics.registerFontFamily('D',normal='D',bold='DB',italic='DI',boldItalic='DB')
NAVY='#132F42'; INK='#18303F'; MUTED='#536674'; RULE='#D6E0E4'; PAPER='#FBFCFB'
PALETTE={'shared':('#EAF2FA','#38668A'),'sunni':('#E6F3EF','#14776B'),'imami':('#F0EAF8','#76529A'),
         'sadrian':('#FBF0D8','#A57520'),'ishraqi':('#F9EADD','#9D6738'),'alternative':('#FAE9E3','#B65B3D'),'modern':('#EAEFF2','#52677B')}
RELS={'commentary':('#304C63',[],1.1,'commentary'), 'gloss':('#14776B',[],1.05,'gloss'),
      'critique':('#AF4F35',[],1.25,'critical response'), 'textual_use':('#527DA0',[5,3],1.05,'explicit use / reworking'),
      'broad_influence':('#826696',[1.5,3],1.05,'broader influence')}

def esc(s):return html.escape(str(s),quote=False)
def tidy(s):
    s=str(s or '')
    s=re.sub(r'\b(Before|before|By|by)(?=\d)',r'\1 ',s)
    s=re.sub(r'(?<=[a-zA-Z])(?=\d{3,4}\b)', ' ', s)
    s=re.sub(r'(?<=\d)(?=vol|volumes|glosses|parts|nodes)', ' ', s)
    s=re.sub(r'(?<=[a-zA-Z])(?=\d)', ' ', s)
    s=re.sub(r'(\d{3,4}) s',r'\1s',s)
    s=re.sub(r'(\d)(AH)',r'\1 \2',s)
    s=s.replace('beforec.','before c.').replace('Dhūl-Qaʿda','Dhū l-Qaʿda').replace('JumādāI','Jumādā I').replace('RajabʿAlī','Rajab ʿAlī').replace('QāḍīSaʿīd','Qāḍī Saʿīd')
    s=re.sub(r'([;,:])(?=\S)',r'\1 ',s)
    s=re.sub(r'(?<!\w)([cd])\.(?=\d)',r'\1. ',s)
    return s
def ps(size=9.3,leading=None,color=INK,bold=False):
    return ParagraphStyle('p',fontName='DB' if bold else 'D',fontSize=size,leading=leading or size*1.4,textColor=HexColor(color),spaceAfter=0,allowWidows=0,allowOrphans=0)
def para(c,txt,x,y,w,size=9.3,color=INK,bold=False,leading=None):
    p=Paragraph(txt,ps(size,leading,color,bold)); _,h=p.wrap(w,10000);p.drawOn(c,x,y-h);return h
def pheight(txt,w,size=9.3,leading=None):
    return Paragraph(txt,ps(size,leading)).wrap(w,10000)[1]
def lines_for(text,width,font='D',size=10):
    lines=[];line=''
    for word in str(text).split():
        test=(line+' '+word).strip()
        if pdfmetrics.stringWidth(test,font,size)<=width or not line: line=test
        else:lines.append(line);line=word
    if line:lines.append(line)
    return lines or ['']
def drawlines(c,ls,x,y,size=10,font='D',leading=None,color=INK):
    c.setFont(font,size);c.setFillColor(HexColor(color));lead=leading or size*1.25
    for line in ls:c.drawString(x,y,line);y-=lead
    return y
def source_refs(ids):
    return ' '.join(f'<link href="#src_{s}" color="#38668A">[{s}]</link>' for s in ids)
def node_ref(n):return f'<b>{esc(n["code"])}</b> {esc(n["title"])} — {esc(n["author"])}'

def load_data():
    data={k:[] for k in ['sources','nodes','edges','notes']}
    for fname in ['foundations.json','sunni.json','iran.json','supplement.json']:
        p=ROOT/'research'/fname
        if p.exists():
            x=json.loads(p.read_text())
            for k in data:data[k].extend(x.get(k,[]))
    for group in ['nodes','edges','sources']:
        ids=[x['id'] for x in data[group]]
        if len(ids)!=len(set(ids)):raise ValueError('Duplicate '+group+': '+str([i for i in ids if ids.count(i)>1]))
    ni={n['id']:n for n in data['nodes']};si={s['id']:s for s in data['sources']}
    for source in data['sources']:
        for k in ['author','title','note']:
            if k in source:source[k]=tidy(source[k])
    # Editorial precision: a lunar year alone does not fix one Gregorian year.
    if 'razi_arba_in' in ni:
        ni['razi_arba_in'].update(date_label='595 AH / 1198–99',date_start=1198,date_end=1199,date_status='range')
    for i,label,start,end in [('damad_qabasat','1034 AH / 1624–25',1624,1625),('ahsai_mashair','1234 AH / 1818–19',1818,1819),('ahsai_arshiyya','1236 AH / 1820–21',1820,1821)]:
        if i in ni:
            ni[i].update(date_label=label,date_start=start,date_end=end,date_status='range')
            ni[i]['date_note']='Reported completion in the stated AH year; without a verified month, the CE equivalent is shown as a two-year span.'
    for i in ['lahiji_shawariq','lahiji_khafri']:
        if i in ni:
            ni[i]['date_label']='before c.1662 (conventional death bound)';ni[i]['date_start']=None
            ni[i]['date_note']='Conventional death bound is uncertain; exact composition year is unverified.'
    if 'lahiji_gawhar' in ni:
        ni['lahiji_gawhar']['date_label']='1642–c.1662 (dedication / death bounds)'
        ni['lahiji_gawhar']['date_note']='Dedication to Shah Abbas II gives the lower bound; c.1662 is the conventional, uncertain death bound.'
    for e in data['edges']:
        if e['id'] in ['I_e28','I_e29']:
            e['relation']='critique';e['label']='critical commentary'
    for n in data['nodes']:
        for k in ['title','author','author_dates','date_label','date_note','note','region','family','size']:
            if k in n:n[k]=tidy(n[k])
        if not n.get('sources'):raise ValueError('No sources '+n['id'])
        for s in n['sources']:
            if s not in si:raise ValueError('Missing source '+s)
    for e in data['edges']:
        if e['source'] not in ni or e['target'] not in ni:raise ValueError('Missing edge endpoint '+str(e))
        if not e.get('evidence') or not e.get('sources'):raise ValueError('Unsupported edge '+str(e))
        for s in e['sources']:
            if s not in si:raise ValueError('Missing edge source '+s)
    ordered=sorted(data['nodes'],key=lambda n:(n.get('date_end') or 9999,n.get('date_start') or n.get('date_end') or 9999,n['author'],n['title']))
    for i,n in enumerate(ordered,1):n['code']=f'W{i:03}'
    data['nodes']=ordered
    (ROOT/'research/merged.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
    return data,ni,si

def get_short_author(a):
    replacements={'Fakhr al-Dīn al-Rāzī':'Fakhr al-Dīn al-Rāzī','Naṣīr al-Dīn al-Ṭūsī':'Naṣīr al-Dīn al-Ṭūsī',
      'Saʿd al-Dīn al-Taftāzānī':'al-Taftāzānī','ʿAḍud al-Dīn al-Ījī':'al-Ījī','al-Sayyid al-Sharīf al-Jurjānī':'al-Jurjānī'}
    return replacements.get(a,a)

def card(n,compact=False):
    w=210 if compact else 238
    title=lines_for(n['title'],w-22,'DB',11 if compact else 11.7)
    author=lines_for(get_short_author(n['author']),w-22,'D',9.4 if compact else 10.1)
    date=lines_for(n['date_label'],w-22,'DB',9.3 if compact else 10.0)
    context=n.get('region','').split(';')[0]
    if n.get('family')=='Tafkik / Khurasan teachings':context='Tafkīk · '+context
    elif n.get('family')=='Shaykhi criticism':context='Shaykhi criticism · Iran / Iraq'
    elif n.get('family')=='Rajab ʿAlī / Qāḍī Saʿīd':context='Rajab ʿAlī / Qāḍī Saʿīd · Iran'
    ctx=lines_for(context,w-22,'D',7.8)
    h=25+len(title)*14+len(author)*12.3+len(date)*12.3+len(ctx)*10+19
    return {'w':w,'h':h,'title':title,'author':author,'date':date,'context':ctx,'compact':compact}

def graph_specs(data,ni):
    allids=set(ni)
    def ids(*a):return [i for i in a if i in ni]
    def match(*families):return [n['id'] for n in data['nodes'] if n['family'] in families]
    specs=[
      dict(id='01_foundations',title='01 · Avicenna, early kalām and Rāzī',subtitle='Shared problems and distinct genres before the fourteenth-century syntheses.',
        nodes=ids('avicenna_shifa','avicenna_isharat','juwayni_shamil','juwayni_irshad','ghazali_tahafut','ghazali_iqtisad','razi_nihaya','razi_mabahith','razi_mulakhkhas','razi_muhassal','razi_arba_in','razi_isharat','razi_matalib','amidi_abkar'),direction='TB'),
      dict(id='02_tusi',title='02 · Ṭūsī and the shared commentary traditions',subtitle='The Ishārāt debate and the Tajrīd are different textual families; both cross confessional boundaries.',
        nodes=ids('avicenna_isharat','razi_isharat','razi_muhassal','tusi_isharat','tusi_talkhis','tusi_tajrid','tusi_asas','hilli_kashf','hilli_nihaya','isfahani_tasdid','jurjani_tajrid','qutb_muhakamat','qushji_tajrid'),direction='TB'),
      dict(id='03_syntheses',title='03 · Ījī, Taftāzānī and Jurjānī',subtitle='The two major Sunni summa traditions are related, but Sharḥ al-Maqāṣid is Taftāzānī’s commentary on his own text.',
        nodes=ids('razi_muhassal','razi_matalib','amidi_abkar','baydawi_tawali','iji_mawaqif','iji_adudiyya','taftazani_maqasid','taftazani_sharh_maqasid','jurjani_mawaqif','nasafi_aqaid','taftazani_aqaid','khayali_maqasid'),direction='TB'),
      dict(id='04_mawaqif',title='04 · The Mawāqif after Jurjānī',subtitle='Ottoman and South Asian glosses: major complete apparatuses and more restricted philosophical investigations.',
        nodes=ids('iji_mawaqif','jurjani_mawaqif','hasan_mawaqif','siyalkuti_mawaqif','mirzahid_mawaqif','khayrabadi_zahidiyya','khayali_mawaqif'),direction='TB'),
      dict(id='05_ottoman_indian',title='05 · Ottoman and South Asian teaching families',subtitle='Nasafī–Taftāzānī and Ījī–Dawwānī form independent, overlapping curricular networks.',
        nodes=ids('nasafi_aqaid','taftazani_aqaid','khayali_aqaid','kesteli_aqaid','isam_aqaid','siyalkuti_khayali','khalid_siyalkuti','iji_adudiyya','dawwani_adudiyya','siyalkuti_adudiyya','gelenbevi_jalal','abduh_dawwani','baydawi_tawali','sajaqlizada_nashr'),direction='TB'),
      dict(id='06_maghrib_egypt',title='06 · Maghrib and Egypt: three commentary families',subtitle='Sanūsī, Laqānī and Dardīr each generate their own matn–commentary–gloss sequences.',
        nodes=match('Sanūsī','Jawhara','Kharīda'),direction='TB'),
      dict(id='07_maturidi_modern',title='07 · Māturīdī continuity and modern Sunni projects',subtitle='Independent modern works are contextual nodes where a particular textual parent has not been established.',
        nodes=match('Māturīdī','Modern Sunni')+ids('nasafi_aqaid','taftazani_aqaid','dawwani_adudiyya','abduh_dawwani'),direction='TB'),
      dict(id='08_tajrid_later',title='08 · The later Tajrīd: debate and Imami syntheses',subtitle='Sunni and Imami readers share a text; a commentary can also criticize other commentators.',
        nodes=ids('tusi_tajrid','hilli_kashf','isfahani_tasdid','jurjani_tajrid','qushji_tajrid','dawwani_tajrid','dashtaki_tajrid','ghiyath_dashtaki_gloss','lahiji_shawariq','lahiji_gawhar'),direction='TB'),
      dict(id='09_iran_syntheses',title='09 · Iranian syntheses and Ṣadrā',subtitle='Kalām, Avicennan philosophy, Illuminationism and Sufi metaphysics intersect without becoming one school.',nodes=[],direction='TB'),
      dict(id='10_sadrian',title='10 · Ṣadrian philosophy into the modern period',subtitle='Large systematic works, teaching manuals and later commentary projects have different kinds of authority.',
        nodes=ids('sadra_asfar','sadra_mashair','sadra_arshiyya','sabzavari_manzuma','sabzavari_asfar','tabatabai_bidaya','tabatabai_nihaya','tabatabai_asfar','javadi_rahiq'),direction='TB'),
      dict(id='11_alternatives',title='11 · Alternatives to Ṣadrā and explicit criticism',subtitle='Rajab ʿAlī / Qāḍī Saʿīd, Shaykhism and Tafkīk are distinct positions; no common descent is assumed.',nodes=[],direction='TB')]
    return specs

def dot_graph(spec,ni,edges,master=False):
    nodeids=list(dict.fromkeys(spec['nodes']));selected=set(nodeids)
    es=[e for e in edges if e['source'] in selected and e['target'] in selected]
    cards={i:card(ni[i],compact=master) for i in nodeids}
    pack='' if master else 'pack=true, packmode="array3", '
    out=['digraph G {','graph [rankdir=TB, '+pack+'bgcolor="transparent", splines=spline, overlap=false, nodesep="0.22", ranksep="0.55", outputorder=edgesfirst, newrank=true, pad="0.10"];',
      'node [shape=box, fixedsize=true, label="", style="rounded", fontname="DejaVu Sans"];',
      'edge [fontname="DejaVu Sans", fontsize=8, arrowsize=0.6, color="#304C63"];']
    for i in nodeids:
        cr=cards[i];out.append(f'"{i}" [width={cr["w"]/72:.4f},height={cr["h"]/72:.4f}];')
    if master:
        # Coarse historical neighborhoods keep independent works visible without inventing links.
        buckets=defaultdict(list)
        for i in nodeids:
            n=ni[i];d=n.get('date_end') or 2000
            bucket= int(d//50)*50
            if d<1050:bucket=1000
            buckets[bucket].append(i)
        ordered=sorted(buckets)
        for b in ordered:
            out.append(f'"era{b}" [width=0.01,height=0.01,shape=point,style=invis];')
            out.append('{rank=same; "era'+str(b)+'"; '+'; '.join('"'+i+'"' for i in buckets[b])+';}')
        for a,b in zip(ordered,ordered[1:]):out.append(f'"era{a}" -> "era{b}" [style=invis,weight=100,minlen=1];')
    for e in es:
        col,dash,pw,_=RELS.get(e['relation'],RELS['broad_influence']);style='dotted' if e['relation']=='broad_influence' or e['confidence']=='qualified' else ('dashed' if dash else 'solid')
        label='' # Edge identifiers are placed after layout, avoiding packed-component label bugs.
        out.append(f'"{e["source"]}" -> "{e["target"]}" [id="{e["id"]}",label="{label}",color="{col}",style={style},penwidth={pw},constraint={"false" if master else "true"}];')
    out.append('}')
    (GR/(spec['id']+'.dot')).write_text('\n'.join(out))
    return {'cards':cards,'edges':es,'nodeids':nodeids}

def draw_path_ops(c,ops):
    for op in ops:
        t=op['op']
        if t=='c':
            v=op['color'];c.setStrokeColor(HexColor(v[:7] if len(v)>7 else v))
        elif t=='C':
            v=op['color'];c.setFillColor(HexColor(v[:7] if len(v)>7 else v))
        elif t=='S':
            st=op.get('style','')
            if st=='dashed':c.setDash(5,3)
            elif st=='dotted':c.setDash(1.5,3)
            elif st=='solid':c.setDash()
            elif st.startswith('setlinewidth'):c.setLineWidth(float(st.split('(')[1].rstrip(')')))
        elif t in ['b','B','L','P','p']:
            pts=op['points'];p=c.beginPath();p.moveTo(*pts[0])
            if t in ['b','B']:
                for z in range(1,len(pts)-2,3):p.curveTo(*pts[z],*pts[z+1],*pts[z+2])
            else:
                for pt in pts[1:]:p.lineTo(*pt)
                if t in ['P','p']:p.close()
            c.drawPath(p,stroke=1,fill=int(t in ['B','P']))
        elif t in ['E','e']:
            x,y,rx,ry=op['rect'];c.ellipse(x-rx,y-ry,x+rx,y+ry,stroke=1,fill=int(t=='E'))

def draw_graph(c,gname,meta,ni,box,links=True):
    geo=json.loads((GR/(gname+'.json')).read_text());bb=[float(v) for v in geo['bb'].split(',')]
    gw,gh=bb[2]-bb[0],bb[3]-bb[1];x,y,w,h=box;scale=min(w/gw,h/gh)
    ox=x+(w-gw*scale)/2;oy=y+(h-gh*scale)/2
    c.saveState();c.translate(ox,oy);c.scale(scale,scale)
    edge_lookup={e['id']:e for e in meta['edges']}
    label_paths=[]
    node_rects=[]
    for o in geo['objects']:
        if o['name'] in meta['cards']:
            cr=meta['cards'][o['name']];cx,cy=map(float,o['pos'].split(','))
            node_rects.append((cx-cr['w']/2-3,cy-cr['h']/2-3,cx+cr['w']/2+3,cy+cr['h']/2+3))
    for e in geo.get('edges',[]):
        eid=e.get('id');
        if eid not in edge_lookup:continue
        item=edge_lookup[eid];col,dash,pw,_=RELS.get(item['relation'],RELS['broad_influence'])
        c.saveState();c.setStrokeColor(HexColor(col));c.setFillColor(HexColor(col));c.setLineWidth(pw);c.setDash(dash)
        draw_path_ops(c,e.get('_draw_',[]));c.setDash();draw_path_ops(c,e.get('_hdraw_',[]));draw_path_ops(c,e.get('_tdraw_',[]))
        for op in e.get('_draw_',[]):
            if op['op'] in ['b','B'] and gname!='00_master':label_paths.append((eid,col,op['points']))
        c.restoreState()
    for o in geo['objects']:
        i=o['name']
        if i not in meta['cards']:continue
        n=ni[i];cr=meta['cards'][i];cx,cy=map(float,o['pos'].split(','));cw,ch=cr['w'],cr['h'];left=cx-cw/2;bottom=cy-ch/2
        fill,border=PALETTE.get(n['tradition'],PALETTE['modern']);c.setFillColor(HexColor(fill));c.setStrokeColor(HexColor(border));c.setLineWidth(.9);c.setDash()
        c.roundRect(left,bottom,cw,ch,6,fill=1,stroke=1)
        c.setFillColor(HexColor(border));c.roundRect(left,bottom+ch-20,cw,20,6,fill=1,stroke=0);c.rect(left,bottom+ch-20,cw,10,fill=1,stroke=0)
        c.setFont('DB',8);c.setFillColor(white);c.drawString(left+10,bottom+ch-13,n['code'])
        kind='GLOSS SERIES' if i in ['dawwani_tajrid','dashtaki_tajrid'] else n['kind'].upper();c.drawRightString(left+cw-10,bottom+ch-13,kind)
        yy=bottom+ch-35;compact=cr['compact']
        yy=drawlines(c,cr['title'],left+11,yy,11 if compact else 11.7,'DB',14)
        yy-=3;yy=drawlines(c,cr['author'],left+11,yy,9.4 if compact else 10.1,'D',12.3)
        yy-=3;yy=drawlines(c,cr['date'],left+11,yy,9.3 if compact else 10,'DB',12.3,color=border)
        yy-=3;drawlines(c,cr['context'],left+11,yy,7.8,'D',10,color=MUTED)
        if links:
            c.linkRect('', 'work_'+i,(left,bottom,left+cw,bottom+ch),relative=1,thickness=0)
    occupied=list(node_rects)
    def hits(r):
        return any(r[0]<s[2] and r[2]>s[0] and r[1]<s[3] and r[3]>s[1] for s in occupied)
    for eid,col,pts in label_paths:
        sampled=[]
        for j in range(0,len(pts)-3,3):
            a,b,cc,dd=pts[j:j+4]
            for z in range(21):
                t=z/20;u=1-t
                sampled.append((u**3*a[0]+3*u*u*t*b[0]+3*u*t*t*cc[0]+t**3*dd[0],u**3*a[1]+3*u*u*t*b[1]+3*u*t*t*cc[1]+t**3*dd[1]))
        if not sampled:continue
        dist=[0]
        for a,b in zip(sampled,sampled[1:]):dist.append(dist[-1]+math.hypot(b[0]-a[0],b[1]-a[1]))
        text=eid.replace('_e','-');size=8.2;tw=pdfmetrics.stringWidth(text,'DB',size);chosen=None
        for frac in [.5,.42,.58,.32,.68,.22,.78,.12,.88]:
            j=min(range(len(dist)),key=lambda j:abs(dist[j]-dist[-1]*frac));tx,ty=sampled[j]
            for dy in [5,-9,14,-18,0]:
                rect=(tx-tw/2-3,ty+dy-3,tx+tw/2+3,ty+dy+8.5)
                if not hits(rect):chosen=(tx,ty+dy,rect);break
            if chosen:break
        if chosen is None:
            tx,ty=sampled[len(sampled)//2];chosen=(tx,ty+5,(tx-tw/2-3,ty+2,tx+tw/2+3,ty+13.5))
        tx,ty,rect=chosen;occupied.append(rect);c.setFillColor(white);c.roundRect(rect[0],rect[1],rect[2]-rect[0],rect[3]-rect[1],2,fill=1,stroke=0)
        c.setFillColor(HexColor(col));c.setFont('DB',size);c.drawCentredString(tx,ty,text)
        if links:c.linkRect('', 'edge_'+eid,rect,relative=1,thickness=0)
    c.restoreState()
    return scale,(gw,gh)

class Doc:
    def __init__(self,path):
        self.c=canvas.Canvas(str(path),pagesize=A4,pageCompression=1)
        self.c.setTitle('Kalām and Philosophical Theology: Dated Textual Genealogies')
        self.c.setAuthor('Research atlas prepared for the reader')
        self.c.setSubject('Sourced textual relationships, dates and traditions, tenth to twenty-first centuries')
        self.p=0;self.size=A4;self.toc=[];self.audit=[]
    def new(self,title=None,size=A4,key=None,section=None):
        if self.p:self.c.showPage()
        self.p+=1;self.size=size;self.c.setPageSize(size);w,h=size
        self.c.setFillColor(HexColor(PAPER));self.c.rect(0,0,w,h,fill=1,stroke=0)
        if key:
            self.c.bookmarkPage(key);self.c.addOutlineEntry(title or key,key,0,False);self.toc.append((title,key,self.p))
        if title:
            self.c.setFillColor(HexColor(NAVY));self.c.setFont('DB',9);self.c.drawString(36,h-29,'KALĀM  /  TEXTUAL GENEALOGIES')
            self.c.setFont('DSB',21 if w<900 else 27);self.c.drawString(36,h-62,title)
            self.c.setStrokeColor(HexColor(RULE));self.c.setLineWidth(.7);self.c.line(36,39,w-36,39)
            self.c.setFont('D',7.5);self.c.setFillColor(HexColor(MUTED));self.c.drawString(36,26,section or 'Dates are work dates or explicitly marked bounds. Sources checked 28 October 2026.')
            self.c.drawRightString(w-36,26,str(self.p))
            if getattr(self,'nav',False):
                self.c.setFont('D',8);self.c.drawRightString(w-36,h-29,'INDEX ↗');self.c.linkRect('','navigation',(w-95,h-38,w-36,h-20),thickness=0)
        return h-85
    def save(self):
        data=self.c.getpdfdata()
        Path(self.c._filename).write_bytes(data)
        print('Saved',Path(self.c._filename).name,len(data),'bytes')

def legend(c,x,y,w,scale=1):
    items=[('shared','Shared philosophy'),('sunni','Sunni kalām'),('imami','Imami kalām'),('sadrian','Ṣadrian philosophy'),('ishraqi','Illuminationist / other synthesis'),('alternative','Alternatives / criticism'),('modern','Modern contextual work')]
    for j,(k,lab) in enumerate(items):
        if w<700:lab={'ishraqi':'Illuminationist','alternative':'Alternatives / critics','modern':'Modern works'}.get(k,lab)
        xx=x+(j%4)*(w/4);yy=y-(j//4)*21;fill,col=PALETTE[k]
        c.setFillColor(HexColor(fill));c.setStrokeColor(HexColor(col));c.roundRect(xx,yy-9,11,11,2,fill=1,stroke=1)
        c.setFillColor(HexColor(INK));c.setFont('D',8.3*scale);c.drawString(xx+17,yy-7,lab)
    yy=y-49
    for j,(k,(col,dash,pw,lab)) in enumerate(RELS.items()):
        xx=x+(j%3)*(w/3);yyy=yy-(j//3)*19
        c.setStrokeColor(HexColor(col));c.setLineWidth(pw);c.setDash(dash);c.line(xx,yyy,xx+26,yyy);c.setDash()
        c.setFillColor(HexColor(INK));c.setFont('D',8.1*scale);c.drawString(xx+33,yyy-3,lab)

def arabic_title(n):
    s=n.get('title_ar','')
    if not s or not any('\u0600'<=z<='\u06ff' for z in s):return None
    p=TMP/('ar_'+n['id']+'.png')
    font=ImageFont.truetype(str(FONTS/'DejaVuSans.ttf'),32,layout_engine=ImageFont.Layout.RAQM)
    bb=font.getbbox(s,direction='rtl');ww=bb[2]-bb[0]+20;hh=bb[3]-bb[1]+16
    im=Image.new('RGBA',(ww,hh),(255,255,255,0));ImageDraw.Draw(im).text((10-bb[0],8-bb[1]),s,font=font,fill=INK,direction='rtl');im.save(p)
    return p,ww,hh

def entry_flow(doc,items,render,height_fn,section_title,key,cols=1,size=A4):
    top=doc.new(section_title,size,key);w,h=size;gap=24;margin=36;cw=(w-2*margin-gap*(cols-1))/cols
    col=0;y=top;bottom=58
    for item in items:
        hh=height_fn(item,cw)
        if y-hh<bottom:
            col+=1;y=top
            if col>=cols:top=doc.new(section_title+' · continued',size);col=0;y=top
        render(item,margin+col*(cw+gap),y,cw,hh);y-=hh

def main():
    data,ni,si=load_data();specs=graph_specs(data,ni)
    # Research-specific memberships can be edited without altering the audited source data.
    cfgpath=ROOT/'research/plate_membership.json'
    if cfgpath.exists():
        cfg=json.loads(cfgpath.read_text())
        for spec in specs:
            if spec['id'] in cfg:spec['nodes']=list(dict.fromkeys(spec['nodes']+cfg[spec['id']]))
    specs=[s for s in specs if s['nodes']]
    master=dict(id='00_master',title='Kalām and philosophical theology',nodes=list(ni))
    metas={s['id']:dot_graph(s,ni,data['edges'],master=s is master) for s in [master]+specs}
    node_exe=os.environ.get('CODEX_PRIMARY_RUNTIME_NODE','node')
    subprocess.run([node_exe,str(ROOT/'render_graphs.mjs'),str(GR)],check=True,stdout=subprocess.PIPE)
    # Standalone overview: adapt the large page to preserve a comfortable minimum card size.
    geo=json.loads((GR/'00_master.json').read_text());bb=list(map(float,geo['bb'].split(',')));gw,gh=bb[2],bb[3]
    mw,mh=landscape(A0)
    s=min((mw-130)/gw,(mh-300)/gh)
    if s<.78:
        mw=max(mw,gw*.78+130);mh=max(mh,gh*.78+300)
    m=Doc(OUT/'Kalam_Genealogies_Master_Map.pdf');m.new('A dated map of texts and their reception',(mw,mh),'overview')
    para(m.c,f'<b>{len(data["nodes"])} text entries · {len(data["edges"])} sourced relationships</b> · Tenth to twenty-first centuries · Read with the companion atlas for dates, qualifications and evidence.',36,mh-90,mw-72,16)
    para(m.c,'Arrow direction: source text → work that comments on, uses or criticizes it. Layout gives broad historical neighborhoods, not a scaled timeline. “Before” is an upper bound, never an exact composition year. Disconnected nodes do not imply intellectual isolation.',36,mh-121,mw-72,12)
    scale,_=draw_graph(m.c,'00_master',metas['00_master'],ni,(50,150,mw-100,mh-320),links=False)
    legend(m.c,42,124,min(mw-84,1100),scale=1.2);m.save()

    d=Doc(OUT/'Kalam_Intellectual_Genealogies_Atlas.pdf');d.nav=True;c=d.c
    d.new(size=A4,key='cover',title=None);w,h=A4
    c.setFillColor(HexColor(NAVY));c.rect(0,h-280,w,280,fill=1,stroke=0)
    c.setFillColor(HexColor('#ABC7CF'));c.setFont('DB',10);c.drawString(40,h-51,'A RESEARCH ATLAS  /  28 OCTOBER 2026')
    y=h-110
    for line in ['Kalām and','philosophical theology']:
        c.setFont('DSB',30);c.setFillColor(white);c.drawString(40,y,line);y-=42
    para(c,'Dated textual genealogies from Rāzī and Ṭūsī<br/>to Sunni and Imami continuations in the modern period',40,h-210,w-80,13,color='#E2EDF0')
    y=h-320
    y-=para(c,f'<b>{len(data["nodes"])} text entries · {len(data["edges"])} supported relationships · {len(specs)} detailed diagrams</b>',40,y,w-80,12)
    y-=22
    y-=para(c,'This atlas answers a question about <b>intellectual descent</b>: which later works actually comment on, draw on, dispute or rework which earlier texts? It distinguishes that evidence from shared vocabulary, personal teaching and chronological succession.',40,y,w-80,12)
    y-=21
    y-=para(c,'Its center is the shared philosophical kalām tradition surrounding <i>al-Mawāqif</i>, <i>al-Maqāṣid</i> and <i>Tajrīd al-iʿtiqād</i>. Ottoman, South Asian, Maghribi, Egyptian and Iranian continuations appear as intersecting networks.',40,y,w-80,11)
    y-=23
    c.setFillColor(HexColor('#E6F3EF'));c.roundRect(40,y-104,w-80,104,8,fill=1,stroke=0)
    para(c,'<b>How to use the atlas</b><br/>Start with the overview and the relevant detailed plate. A work’s W-number leads to its dated catalogue entry. Each labeled arrow leads to the relationship register. Source IDs lead to a linked bibliography.',55,y-15,w-110,10.5)
    c.setFont('D',8.2);c.setFillColor(HexColor(MUTED));c.drawString(40,36,'A selective, evidence-led map. No single text is designated the final form of an entire tradition.')

    y=d.new('Reading the map',A4,'method')
    blocks=[
      ('What counts as a relationship?', 'A solid commentary or gloss arrow identifies a textual object: the later work is on the earlier one. A critical-response arrow points from the target to its critic. Dashed arrows mark explicit use or reworking; dotted arrows mark a broader or qualified connection, including qualified criticism. The register explains the evidence. These are different claims, not degrees of approval.'),
      ('What the dates mean', 'All unqualified numeric years are CE; AH dates are supplied where verified. “Completed” refers to a documented completion. “c.” and ranges mark approximation. “Before” or “by” is a latest possible bound, commonly an author’s death or the earliest checked printed witness. Publication, revision and manuscript-copy dates are identified separately. A death bound is not a proposed composition year.'),
      ('What the colors mean', 'Colors group a work’s main setting in this map. They do not settle every disputed affiliation or imply that all readers shared its doctrine. Region and confessional affiliation are separate fields in the catalogue. A Sunni scholar can comment on Ṭūsī; a work produced in Iran need not be Imami; an Imami philosopher need not be Ṣadrian.'),
      ('What the arrangement does not prove', 'The overview groups texts into broad historical neighborhoods for readability. It is not a scaled timeline. An unconnected work is included as context where a named-work relationship has not been established here. Absence of an arrow means “not documented in this atlas,” not “no influence existed.” Diagram position does not establish chronology.'),
      ('Scope', 'The selection follows the text families requested, with early anchors and modern continuations. It is not a complete history of Islamic theology. Early Muʿtazilī and Imami developments, Zaydī and Ismaili theology, Atharī criticism, logic, Sufism and the Southeast Asian reception each require a separate atlas. Only relevant intersections are included. Teacher–student relations are not silently substituted for textual dependencies.')]
    for head,body in blocks:
        y-=para(c,esc(head),36,y,w-72,12,bold=True)+5;y-=para(c,esc(body),36,y,w-72,9.5)+16
    y=d.new('Legend and principal findings',A4,'findings')
    legend(c,36,y-3,w-72);y-=112
    findings=[
      ('Ījī → Taftāzānī is demonstrable.', 'Sharḥ al-Maqāṣid explicitly refers to al-Mawāqif. It is nonetheless a commentary on Taftāzānī’s own Maqāṣid. The alleged personal pupil relationship is a separate, contested issue.'),
      ('The relevant chronology is finer than death dates.', 'Taftāzānī’s Maqāṣid and commentary were completed in Dhū l-Qaʿda 784 / January 1383. Jurjānī’s Sharḥ al-Mawāqif records completion in Shawwāl 807 / 1405. Ījī’s Mawāqif has a complex revision history; the catalogue states the limits of its dating.'),
      ('There is no universally final Sunni gloss.', 'The Jurjānī–Ḥasan Çelebi–Siyālkūtī corpus is a major candidate for the mature Mawāqif tradition. Mīr Zāhid and ʿAbd al-Ḥaqq Khayrābādī extend selected philosophical portions. Parallel creed-commentary families and modern independent works prevent a single terminal sequence.'),
      ('The Imami comparison has more than one axis.', 'Ṭūsī’s Tajrīd and its commentaries are the nearest textual counterpart to the Sunni commentary networks. Lāhījī’s Shawāriq is an extensive but unfinished kalām commentary. Ṣadrā’s Asfār and its reception supply a major philosophical system; other Imami intellectual lineages continue alongside and against it.'),
      ('Size, reception and rigor must be assessed separately.', 'An edition’s volume count measures publishing choices as well as textual extent. A difficult and original work need not be a standard textbook. Commentary status need not mean agreement with every position in the base text.')]
    finding_sources=[['F27','F29'],['F26','F27','F30'],['S01','S02','S04','S29'],['F19','I14','I11'],[]]
    for j,(head,body) in enumerate(findings):
        y-=para(c,esc(head),36,y,w-72,10.8,bold=True)+3;y-=para(c,esc(body)+' '+source_refs(finding_sources[j]),36,y,w-72,9.1)+13
    para(c,'Specific evidence and bibliographical qualifications are attached to the corresponding works and arrows in the registers.',36,59,w-72,8.1,color=MUTED)

    d.new('Overview · all mapped works and relationships',(mw,mh),'full_overview')
    para(c,f'<b>{len(ni)} text entries · {len(data["edges"])} sourced relationships.</b> Large vector page: zoom to inspect. Work boxes link to the catalogue. Coarse historical arrangement is not a scaled timeline.',36,mh-90,mw-72,16)
    para(c,'Read arrows from the earlier/source work to its later commentator, reader or critic. Qualified or corpus-level relations are dotted. Each detailed plate adds clickable arrow identifiers.',36,mh-121,mw-72,12)
    draw_graph(c,'00_master',metas['00_master'],ni,(50,150,mw-100,mh-320))
    legend(c,42,124,min(mw-84,1100),scale=1.2)

    # Diagram plates: all are vector pages; sizes adjust only where needed for legibility.
    for spec in specs:
        sw,sh=landscape(A3)
        gg=json.loads((GR/(spec['id']+'.json')).read_text());bb2=list(map(float,gg['bb'].split(',')))
        sw=max(sw,bb2[2]*.86+60);sh=max(sh,bb2[3]*.86+288)
        y=d.new(spec['title'],(sw,sh),spec['id']);para(c,esc(spec['subtitle']),36,y,sw-72,10.7)
        sc, dims=draw_graph(c,spec['id'],metas[spec['id']],ni,(30,165,sw-60,sh-288))
        legend(c,36,136,sw-72)
        d.audit.append({'plate':spec['id'],'nodes':len(spec['nodes']),'scale':sc,'min_font_pt':round(sc*8,2),'graph_size':dims})
        para(c,'Click a work box for its catalogue entry or an arrow ID for its evidence. Dotted arrows are broader or qualified relationships.',36,53,sw-72,8.4,color=MUTED)

    # Work catalogue. Each entry is kept together; a bookmark is placed at the entry.
    def work_text(n):
        extra=''
        if n.get('size'):extra='<br/><b>Scale / edition:</b> '+esc(n['size'])
        return (f'<b>Work date:</b> {esc(n["date_label"])}. {esc(n.get("date_note",""))}<br/>'
          f'<b>Setting:</b> {esc(n.get("region",""))} · {esc(n.get("family",""))}. '
          f'<b>Type:</b> {esc(n["kind"])}.<br/>{esc(n.get("note",""))}{extra}<br/>{source_refs(n["sources"])}')
    def wh(n,cw):
        return pheight(f'<b>{n["code"]} · {esc(n["title"])}</b>',cw,12)+pheight(f'{esc(n["author"])} ({esc(n["author_dates"])})',cw,9.6)+pheight(work_text(n),cw,9)+40+(20 if n.get('title_ar') else 0)
    def wr(n,x,y,cw,hh):
        c.bookmarkHorizontal('work_'+n['id'],0,y)
        col=PALETTE.get(n['tradition'],PALETTE['modern'])[1]
        y-=para(c,f'<b>{n["code"]} · {esc(n["title"])}</b>',x,y,cw,12,color=col)+3
        y-=para(c,f'{esc(n["author"])} ({esc(n["author_dates"])})',x,y,cw,9.6)+7
        ar=arabic_title(n)
        if ar:
            p,iw,ih=ar;dh=16;dw=min(cw,iw*dh/ih);dh=dw*ih/iw;c.drawImage(str(p),x+cw-dw,y-dh,width=dw,height=dh,mask='auto');y-=dh+6
        used=para(c,work_text(n),x,y,cw,9)
        c.setStrokeColor(HexColor(RULE));c.line(x,y-used-11,x+cw,y-used-11)
    entry_flow(d,data['nodes'],wr,wh,'Dated catalogue of works','catalogue',size=A4)

    # Relationship register. Exact arrow direction is restated to avoid ambiguity.
    def et(e):
        return f'<b>{esc(e["id"].replace("_e","-"))} · {esc(RELS.get(e["relation"],RELS["broad_influence"])[3])}</b> · {esc(e["confidence"])}<br/>'\
          f'<link href="#work_{e["source"]}" color="#38668A">{node_ref(ni[e["source"]])}</link><br/>→ <link href="#work_{e["target"]}" color="#38668A">{node_ref(ni[e["target"]])}</link><br/>'\
          f'{esc(tidy(e["evidence"]))}<br/>{source_refs(e["sources"])}'
    def eh(e,cw):return pheight(et(e),cw,8.6)+21
    def er(e,x,y,cw,hh):
        c.bookmarkHorizontal('edge_'+e['id'],0,y);used=para(c,et(e),x,y,cw,8.6);c.setStrokeColor(HexColor(RULE));c.line(x,y-used-10,x+cw,y-used-10)
    entry_flow(d,data['edges'],er,eh,'Evidence for each relationship','relationships',cols=2,size=landscape(A4))

    # Source notes: compact, individually linked, and searchable by source ID.
    def st(s):
        url=s.get('url','')
        return f'<b>{esc(s["id"])} · {esc(s.get("author",""))}</b><br/>{esc(s["title"])}<br/>'\
          f'<b>{esc(s.get("type","source"))}</b> · {esc(tidy(s.get("note","")))}<br/>'\
          f'<link href="{html.escape(url,quote=True)}" color="#38668A">Open source ↗</link> · accessed {esc(s.get("accessed","2026-10-28"))}'
    def sh(s,cw):return pheight(st(s),cw,8.7)+21
    def sr(s,x,y,cw,hh):
        c.bookmarkHorizontal('src_'+s['id'],0,y);used=para(c,st(s),x,y,cw,8.7);c.setStrokeColor(HexColor(RULE));c.line(x,y-used-10,x+cw,y-used-10)
    entry_flow(d,data['sources'],sr,sh,'Sources and bibliographical notes','sources',cols=2,size=landscape(A4))

    # Remaining research cautions are retained rather than erased by the diagrams.
    def nt(n):return f'<b>{esc(n["title"])}</b><br/>{esc(tidy(n["text"]))}<br/>{source_refs(n.get("sources",[]))}'
    entry_flow(d,data['notes'],lambda n,x,y,cw,hh:para(c,nt(n),x,y,cw,9),lambda n,cw:pheight(nt(n),cw,9)+20,'Research qualifications','qualifications',size=A4)
    y=d.new('Navigation index',A4,'navigation')
    for title,key,pg in d.toc[:-1]:
        if title is None:title='Cover and orientation'
        txt=f'<link href="#{key}" color="#38668A">{esc(title)}</link>'
        hh=pheight(txt,w-100,10.2)
        if y-hh<64:y=d.new('Navigation index · continued',A4)
        para(c,txt,36,y,w-100,10.2);c.setFont('DB',10);c.setFillColor(HexColor(INK));c.drawRightString(w-36,y-11,str(pg));y-=hh+12
    d.save()
    audit={'works':len(ni),'relationships':len(data['edges']),'sources':len(si),'atlas_pages':d.p,'poster_size_pt':[mw,mh],'poster_min_font':round(scale*9.3,2),'plates':d.audit}
    (TMP/'build_audit.json').write_text(json.dumps(audit,indent=2));print(json.dumps(audit,indent=2))

if __name__=='__main__':main()
