"""Prepare the shared chronological view without changing the audited corpus.

Numerical anchors are layout positions. Ranges, bounds and context entries retain
their different semantics; an anchor is never an inferred composition year.
"""
from pathlib import Path
import json, copy, re, hashlib
from collections import Counter

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'timeline'; OUT.mkdir(exist_ok=True)
D=copy.deepcopy(json.loads((ROOT/'research_v2/merged.json').read_text()))

SUMMARY='''avicenna_shifa avicenna_isharat bahmanyar_tahsil lawkari_bayan
ghazali_tahafut ghazali_iqtisad razi_mabahith razi_nihaya razi_isharat
razi_muhassal razi_matalib amidi_abkar suhrawardi_ishraq suhrawardi_hayakil
ibnarabi_fusus ibnarabi_futuhat tusi_isharat tusi_tajrid ibnkammuna_isharat
ibnkammuna_jadid abh_hidaya katibi_hikma qunawi_miftah qunawi_nusus
shahrazuri_shajara shahrazuri_ishraq qutb_shirazi_ishraq hilli_kashf
qaysari_fusus haydar_jami iji_mawaqif qutb_muhakamat taftazani_maqasid
taftazani_sharh_maqasid taftazani_aqaid jurjani_mawaqif jurjani_tajrid
haydar_nass fanari_misbah turka_tamhid jami_naqd jami_durra dawwani_zawra
dawwani_sharh_zawra dawwani_tajrid dashtaki_tajrid maybudi_hidaya
hasan_mawaqif ibnjumhur_mujli sanusi_sughra laqani_jawhara damad_qabasat
sadra_asfar sadra_shifa sadra_mashair alawi_shifa lahiji_shawariq
siyalkuti_mawaqif mirzahid_mawaqif nabulusi_anwar dara_sirr
qadi_tawhid naraqi_shifa bahrululum_mathnawi ahsai_mashair
sabzavari_manzuma abdqadir_mawaqif kumijani_nur jilveh_shifa
abduh_risala shibli_ilm_kalam izmirli_yeni konuk_fusus khomeini_taliqat
sabri_mawqif tabatabai_bidaya tabatabai_nihaya motahhari_shifa
hakimi_tafkik javadi_rahiq kindi_first arabic_theology arabic_pure_good
hunayn_risala ashari_luma maturidi_tawhid saadia_amanat farabi_madina
abdjabb_mughni mufid_awail baqillani_tamhid juwayni_irshad
saduq_kamal plato_timaeus aristotle_metaphysics plotinus_enneads
proclus_elements philoponus_proclus'''.split()
FEATURED='''kindi_first arabic_theology ashari_luma maturidi_tawhid farabi_madina
abdjabb_mughni avicenna_shifa ghazali_tahafut razi_matalib suhrawardi_ishraq
ibnarabi_fusus tusi_isharat tusi_tajrid shahrazuri_ishraq iji_mawaqif
qaysari_fusus taftazani_sharh_maqasid jurjani_mawaqif haydar_nass
fanari_misbah jami_durra maybudi_hidaya sanusi_sughra damad_qabasat
sadra_asfar lahiji_shawariq siyalkuti_mawaqif nabulusi_anwar naraqi_shifa
bahrululum_mathnawi ahsai_mashair sabzavari_manzuma kumijani_nur
jilveh_shifa abduh_risala konuk_fusus tabatabai_nihaya javadi_rahiq'''.split()

def temporal(n):
    a,b=n.get('date_start'),n.get('date_end'); status=n.get('date_status','')
    basis='composition or textual activity'
    if n.get('node_type')!='work':basis='corpus or contextual dating'
    if 'publication' in (n.get('date_note','')+' '+n.get('date_label','')).lower() or 'printed witness' in n.get('date_label','').lower():basis='publication / attestation bound'
    if a is None and b is None:
        return dict(start=None,end=None,anchor=None,kind='undated',basis=basis,label=n['date_label'],note='Unplaced on the numerical axis. The catalogue states what is known; no ancient date is invented.')
    if a is None:
        kind='upper_bound'; anchor=b
        note='The cap marks a latest bound or attestation, not a verified composition year. The open direction has no established lower endpoint.'
    elif b is None:
        kind='lower_bound'; anchor=a
        note='The cap marks an earliest bound; no closing date is established.'
    elif a==b:
        kind='exact' if status in ('exact','dated','completion') else 'approximate'
        anchor=a;note='Year-level date; read the original date label for finer precision and qualifications.'
    else:
        kind='context' if n.get('node_type')!='work' else 'range'
        anchor=(a+b)/2
        note='The band spans the dated range or multiple stages stated in the label; it does not assert continuous composition. Its centre only positions the label.'
    t=dict(start=a,end=b,anchor=anchor,kind=kind,basis=basis,label=n['date_label'],note=note)
    if a is not None and b is not None and a!=b and status in ('approximate','period','uncertain'):
        t['window_approximate']=True
        t['note']='An approximate catalogue window supports positioning. Its numerical endpoints add no precision beyond the original date label; the centre only positions that label.'
    if n['id']=='isfahani_abwab':
        t['basis']='author-death bound'
        t['note']='1946 is the author-death bound. The later posthumous publication mentioned in the catalogue does not date composition.'
    if n['id']=='abduh_basair':
        t.update(kind='publication',basis='annotated publication',note='1898 dates the annotated publication, rather than a newly inferred date of the medieval base text.')
    if n['id']=='hilli_nihaya':
        t.update(start=1320,end=1320,anchor=1320,kind='approximate',basis='approximate dating of the extant portion',note='Writing began before 1297; c.1320 concerns the extant portion. The plotted approximation is not a whole-work completion bound.')
    if n['id']=='kumijani_nur':
        t.update(start=1886,end=1887,anchor=1886.5,kind='range',basis='final recension',note='The label explicitly dates the final form to 1886–87. Earlier writing is attested before 1872–73; this bar is not the full writing duration.')
    if n['id']=='javadi_rahiq':
        t.update(start=2002,end=2003,anchor=2003,kind='publication',basis='early publication attestation',note='Shows the early publication witness in 2002–03. Later volumes continued in the 21st century; no final composition or series-closing date is asserted. The original catalogue range is preserved separately.')
    if n['id']=='upanishads_selection':
        t.update(start=None,end=None,anchor=None,kind='undated',basis='undated source-text strata',note='The 1657 Persian translation supplies a reception witness, not a date of origin for the selected Sanskrit texts. Kept in the undated context rail.')
    if n['id'].startswith('sadra_') and a is None and b==1641:
        t['note']='Conditional upper bound: before 1636 on the revised death chronology, before 1640/41 on the traditional one. Neither is a composition year.'
    return t

for n in D['nodes']:
    n['temporal']=temporal(n)
    n['summary']=n['id'] in SUMMARY
    n['featured']=n['id'] in FEATURED
    n['search_aliases']=[]
    if 'avicenna' in n['id']:n['search_aliases']=['Avicenna','Ibn Sina','Ibn Sīnā','ابن سينا']
    if n['id']=='jurjani_mawaqif':n['search_aliases']=['Sharh al Mawaqif','Sharh al-Mawaqif','شرح المواقف','Jurjani','Gurgani']

H=dict(periods=[],rulers=[],events=[],sources=[],method_notes=[])
for f in ['history_early.json','history_late.json']:
    if (OUT/f).exists():
        part=json.loads((OUT/f).read_text())
        for k in H:H[k].extend(part.get(k,[]))
# Source aliases are allowed, but record IDs must be unique.
for k in ['periods','rulers','events','sources']:
    vals={}
    for x in H[k]:
        if x['id'] in vals and vals[x['id']]!=x:raise ValueError((k,x['id']))
        vals[x['id']]=x
    H[k]=list(vals.values())
for kind in ['periods','rulers','events']:
    for x in H[kind]:
        x.setdefault('kind',{'periods':'polity','rulers':'ruler','events':'event'}[kind])
        x['record_group']=kind
        if not x.get('date_label'):x['date_label']=str(x.get('year',x.get('start','')))
        for field in ['label','date_label','note','role','region','track']:
            if field in x and isinstance(x[field],str):
                x[field]=re.sub(r'(\d{3,4}) s\b',r'\1s',x[field])
                x[field]=re.sub(r'\b(c\.)(?=\d)',r'\1 ',x[field])

D['history']=H
D['timeline_meta']={
 'title':'Texts in time: Islamic intellectual traditions and historical context',
 'version':'2.0','prepared':'28 October 2026','main_domain':[570,2026],'ancient_domain':[-600,570],
 'source_register':'Critical genealogies, revision 2; all 295 entries and 286 relationships retained.',
 'source_sha256':hashlib.sha256((ROOT/'research_v2/merged.json').read_bytes()).hexdigest(),
 'selection_note':'Selected political context for the regions represented by this corpus; not an exhaustive global history of Islam. Reign and polity spans are not borders or influence claims.',
 'dating_note':'Anchors place labels only. Intervals, upper bounds, publication witnesses, corpus spans and undated entries are visually distinct. No exact composition date is inferred from a death bound.',
 'history_relation_note':'Political bars and events supply chronological context. They create no new textual-influence arrows.',
 'default_work':'jurjani_mawaqif',
 'summary_count':sum(n['summary'] for n in D['nodes']),
 'featured_count':sum(n['featured'] for n in D['nodes']),
}
display=json.loads((OUT/'integrated_display.json').read_text())
display['period_ids']=[p['id'] for p in H['periods'] if p['id'] not in display['excluded_period_ids']]
D['timeline_meta']['integrated_display']=display
D['author_index']=[]
authors={}
for n in D['nodes']:
    key=n['author']
    if key not in authors:authors[key]=dict(id='author_'+hashlib.sha1(key.encode()).hexdigest()[:10],name=key,date_labels=[],works=[])
    if n.get('author_dates') and n['author_dates'] not in authors[key]['date_labels']:authors[key]['date_labels'].append(n['author_dates'])
    authors[key]['works'].append(n['id'])
D['author_index']=list(authors.values())
(OUT/'timeline_data.json').write_text(json.dumps(D,ensure_ascii=False,indent=2))
print(json.dumps({'nodes':len(D['nodes']),'edges':len(D['edges']),'temporal_kinds':dict(Counter(n['temporal']['kind'] for n in D['nodes'])),'history':{k:len(v) for k,v in H.items()},'authors':len(D['author_index'])},indent=2))
