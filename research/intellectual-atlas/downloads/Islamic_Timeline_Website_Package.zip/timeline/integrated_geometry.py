"""One proportional chronology: compact polities and interleaved texts/events."""

def layout(data, lo, hi, nodes, width, node_card, history=True, undated=False):
    left, right = 48, 238
    xx = lambda value: left + (value-lo)/(hi-lo)*(width-left-right)
    display=data['timeline_meta']['integrated_display']
    periods=[]
    if history:
        periods=[p for p in data['history']['periods']
                 if p['id'] in display['period_ids'] and p['end']>=lo and p['start']<=hi]
    ends=[]; hist_draw=[]; history_positions={}
    for p in sorted(periods,key=lambda z:(z['start'],z['end'])):
        x1,x2=xx(max(lo,p['start'])),xx(min(hi,p['end']))
        ww=min(230,max(120,x2-x1))
        label_x=min(x1,width-40-ww)
        occupied_left=min(x1,label_x)
        occupied_right=max(x2,label_x+ww)
        slot=next((i for i,e in enumerate(ends) if e+10<occupied_left),len(ends))
        if slot==len(ends): ends.append(occupied_right)
        else: ends[slot]=occupied_right
        yy=177+slot*37
        hist_draw.append(dict(h=p,x1=x1,x2=x2,label_x=label_x,y=yy,w=ww))
        history_positions[p['id']]=(x1,yy)
    axis_y=177+len(ends)*37+10 if periods else 170
    text_top=axis_y+26
    rows=[]; placed=[]; events=[]; positions={}; entries=[]
    for n in nodes:
        t=n['temporal']
        if t['anchor'] is None:continue
        cc=node_card(n,205); ax=xx(t['anchor'])
        cx=min(ax+9,width-40-cc['w'])
        start=min(ax,cx,xx(max(lo,t['start']))) if t['start'] is not None else min(ax-20,cx)
        stop=max(cx+cc['w'],xx(min(hi,t['end']))) if t['end'] is not None else cx+cc['w']
        entries.append((ax,1,n,cc,cx,start,stop))
    if history:
        for e in data['history']['events']:
            a=e.get('year',e.get('start'));b=e.get('end_year',a)
            if b is None:b=a
            if a>hi or b<lo:continue
            ax=xx(max(lo,a));cw=205;cx=min(ax+9,width-40-cw)
            entries.append((ax,0,e,dict(w=cw,h=37),cx,min(ax,cx),cx+cw))
    for ax,kind,item,cc,cx,start,stop in sorted(entries,key=lambda z:(z[0],z[1],z[2]['id'])):
        slot=next((i for i,e in enumerate(rows) if e+12<start),len(rows))
        if slot==len(rows):rows.append(stop)
        else:rows[slot]=stop
        yy=text_top+slot*62
        if kind:
            positions[item['id']]=(ax,yy+6)
            placed.append(dict(n=item,card=cc,x=cx,y=yy,anchor_x=ax))
        else:
            events.append(dict(h=item,card=cc,x=cx,y=yy,anchor_x=ax))
            history_positions[item['id']]=(ax,yy)
    field_bottom=text_top+max(1,len(rows))*62+8
    y=field_bottom
    if undated:
        contexts=[n for n in nodes if n['temporal']['anchor'] is None]
        if contexts:
            y+=34; x0=left
            for n in contexts:
                cc=node_card(n,260)
                if x0+260>width-40:x0=left;y+=55
                positions[n['id']]=(x0-9,y+6)
                placed.append(dict(n=n,card=cc,x=x0,y=y,anchor_x=x0-9,undated=True))
                x0+=310
            y+=50
    chosen={n['id'] for n in nodes}
    edges=[e for e in data['edges'] if e['source'] in positions and e['target'] in positions]
    external=[e for e in data['edges'] if (e['source'] in chosen)!=(e['target'] in chosen)]
    return dict(width=width,height=y+145,left=left,right=right,lo=lo,hi=hi,
                xx=xx,hist_draw=hist_draw,event_draw=events,axis_y=axis_y,
                field_bottom=field_bottom,text_top=text_top,positions=positions,
                placed=placed,edges=edges,external=external,
                history_positions=history_positions,history_rows=[],lanes=[])
