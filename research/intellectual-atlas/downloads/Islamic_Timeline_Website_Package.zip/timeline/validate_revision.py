"""Verify preserved research, integrated layout policy and PDF destinations."""
from pathlib import Path
import json
import fitz

ROOT=Path(__file__).resolve().parents[1]
original=json.loads((ROOT/'research_v2/merged.json').read_text())
data=json.loads((ROOT/'timeline/timeline_data.json').read_text())
audit=json.loads((ROOT/'tmp/timeline/build_audit.json').read_text())
out=ROOT/'tmp/timeline';out.mkdir(parents=True,exist_ok=True)
nodes={n['id']:n for n in data['nodes']}
assert len(nodes)==295
for n in original['nodes']:
    assert all(nodes[n['id']].get(k)==v for k,v in n.items()), n['id']
for key in ['edges','sources','audit','prior_edge_audit','notes']:
    assert original[key]==data[key], key
source_ids={s['id'] for s in data['sources']+data['history']['sources']}
for e in data['edges']:
    assert e['source'] in nodes and e['target'] in nodes
    assert set(e['sources'])<=source_ids
for group in ['periods','rulers','events']:
    for x in data['history'][group]: assert set(x.get('sources',[]))<=source_ids
display=data['timeline_meta']['integrated_display']
assert len(display['period_ids'])==45 and 'HEP05' not in display['period_ids']
master=audit['maps'][0]
assert set(master['nodes'])==set(nodes)
assert set(master['edges'])=={e['id'] for e in data['edges']}
assert set(master['periods'])==set(display['period_ids'])
assert set(master['events'])=={e['id'] for e in data['history']['events']}
assert all(m['rulers']==[] for m in audit['maps'])
assert len(audit['work_pages'])==295 and len(audit['edge_pages'])==286
assert len(audit['history_pages'])==81
checks=[]
for p in sorted((ROOT/'output/timeline').glob('*.pdf')):
    doc=fitz.open(p);outside=[];bad=[];links=0
    for i,page in enumerate(doc):
        for block in page.get_text('blocks'):
            if block[0]<-1 or block[1]<-1 or block[2]>page.rect.width+1 or block[3]>page.rect.height+1:
                outside.append({'page':i+1,'text':block[4][:80]})
        for link in page.get_links():
            links+=1
            if link.get('kind')==fitz.LINK_GOTO and not 0<=link.get('page',-1)<len(doc):bad.append({'page':i+1,'link':link})
    checks.append({'file':p.name,'pages':len(doc),'links':links,'out_of_bounds':outside,'invalid_internal_links':bad})
    assert not outside and not bad,p.name
report={'status':'passed','original_entries_preserved':len(nodes),'original_relations_preserved':len(data['edges']),
        'original_sources_preserved':len(original['sources']),'displayed_periods':45,'displayed_events':36,
        'displayed_rulers':0,'archived_ruler_records':len(data['history']['rulers']),
        'upper_bounds':sum(n['temporal']['kind']=='upper_bound' for n in nodes.values()),
        'pdfs':checks,'complete_map_entries':len(master['nodes']),'complete_map_edges':len(master['edges'])}
(out/'revision_validation.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
