"""Build the self-contained timeline prototype and conversation fragment.

The original research register is preserved in full. A normalized temporal
register and sourced historical context are used when available.
"""
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'timeline/timeline_data.json'
if not DATA.exists():
    DATA = ROOT / 'research_v2/merged.json'
d = json.loads(DATA.read_text())
if 'history' not in d:
    h = dict(periods=[], rulers=[], events=[], sources=[], method_notes=[])
    for name in ('history_early.json', 'history_late.json'):
        p = ROOT / 'timeline' / name
        if p.exists():
            part = json.loads(p.read_text())
            for k in h:
                h[k].extend(part.get(k, []))
    d['history'] = h

template = (ROOT / 'timeline/interactive_template.html').read_text()
payload = json.dumps(d, ensure_ascii=False, separators=(',', ':')).replace('</', '<\\/')
base = template.replace('__ATLAS_JSON__', payload)
fragment = base.replace('__INLINE_PREVIEW__', 'true')
standalone = base.replace('__INLINE_PREVIEW__', 'false')
assert '__ATLAS_JSON__' not in fragment
assert len(fragment.encode()) < 1024 * 1024, 'Conversation fragment exceeds 1 MiB'
fp = ROOT / 'integrated-intellectual-timeline.html'
fp.write_text(fragment)
out = ROOT / 'output/timeline/Islamic_Intellectual_Timeline.html'
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text('<!doctype html>\n<html lang="en"><head><meta charset="utf-8">'
               '<meta name="viewport" content="width=device-width,initial-scale=1">'
               '<meta name="color-scheme" content="light dark">'
               '<title>Intellectual Atlas | Historical Timeline</title>'
               '<style>body{margin:0;background:light-dark(#f7f7f4,#14191c);'
               'font-family:system-ui,sans-serif}*{box-sizing:border-box}</style>'
               '</head><body>\n' + standalone + '\n</body></html>')
print(json.dumps({'fragment': str(fp), 'standalone': str(out),
                  'bytes': len(fragment.encode()), 'entries': len(d['nodes']),
                  'relations': len(d['edges']),
                  'historical_periods': len(d.get('history', {}).get('periods', [])),
                  'historical_rulers': len(d.get('history', {}).get('rulers', [])),
                  'historical_events': len(d.get('history', {}).get('events', []))}, indent=2))
