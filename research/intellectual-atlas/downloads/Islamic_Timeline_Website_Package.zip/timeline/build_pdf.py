"""Horizontal, proportional chronology plus the complete audited registers."""
from pathlib import Path
import sys, json, math, copy, html
from collections import defaultdict, Counter
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import build_kalam_atlas_v2 as v
import build_kalam_atlas as b
from reportlab.lib.colors import HexColor, white
from reportlab.lib.pagesizes import A4,A3,landscape
from reportlab.pdfbase import pdfmetrics

OUT=ROOT/'output/timeline'; OUT.mkdir(parents=True,exist_ok=True)
TMP=ROOT/'tmp/timeline'; TMP.mkdir(parents=True,exist_ok=True)
D=json.loads((ROOT/'timeline/timeline_data.json').read_text())
NI={n['id']:n for n in D['nodes']}
PALETTE=v.PALETTE; RELS=v.RELS
INK='#173547'; MUTED='#52697A'; PAPER='#FBFCFD'; RULE='#D5DFE6'; NAVY='#123449'
esc=v.esc;para=v.para;pheight=v.pheight;lines_for=v.lines_for
STREAMS=list(PALETTE)
TECH_SOURCES=[
 dict(id='WEB01',author='D3 documentation',title='d3-zoom: pointer, touch and programmatic zoom',url='https://d3js.org/d3-zoom',type='official documentation',note='Supports the proposed SVG pan/zoom and focus/context interaction.'),
 dict(id='WEB02',author='D3 documentation',title='Linear scales',url='https://d3js.org/d3-scale/linear',type='official documentation',note='A proportional mapping preserves differences on the chronological axis.'),
 dict(id='WEB03',author='W3C Web Accessibility Initiative',title='Understanding WCAG 2.2: Target Size (Minimum)',url='https://www.w3.org/WAI/WCAG22/Understanding/target-size-minimum.html',type='official documentation',note='24 CSS-pixel minimum or qualifying spacing; larger touch targets improve usability.'),
 dict(id='WEB04',author='W3C Web Accessibility Initiative',title='Understanding WCAG 2.2: Content on Hover or Focus',url='https://www.w3.org/WAI/WCAG22/Understanding/content-on-hover-or-focus.html',type='official documentation',note='Temporary additional content must remain perceivable and dismissible. Persistent selection panels are the proposed default.')]

class Doc(v.Doc):
 def __init__(self,path,linked=True):
  super().__init__(path,nav=linked);self.linked=linked;self.history_pages={};self.map_records=[]
  self.c.setTitle('Texts in time: Islamic intellectual traditions and historical context')
  self.c.setSubject('Proportional horizontal timelines, political contexts, uncertain text dates and evidence-aware interaction')
 def new(self,title=None,size=A4,key=None,section=None):
  if self.p:self.c.showPage()
  self.p+=1;self.size=size;self.c.setPageSize(size);w,h=size;c=self.c
  c.setFillColor(HexColor(PAPER));c.rect(0,0,w,h,fill=1,stroke=0)
  if key:
   c.bookmarkPage(key);c.addOutlineEntry(title or 'Cover',key,0,False);self.toc.append((title,key,self.p))
  if title:
   c.setFillColor(HexColor(NAVY));c.setFont('DB',8.5);c.drawString(36,h-28,'TEXTS IN TIME · HISTORICAL CONTEXT AND TEXTUAL RELATIONS')
   fs=21 if w<900 else 29 if w<4000 else 40
   used=para(c,esc(title),36,h-47,w-72,fs,color=NAVY,bold=True,leading=fs*1.15)
   c.setStrokeColor(HexColor(RULE));c.line(36,39,w-36,39)
   c.setFont('D',7.4);c.setFillColor(HexColor(MUTED));c.drawString(36,26,section or '28 October 2026 · Context is not causation. Bounds are not composition years.')
   c.drawRightString(w-36,26,str(self.p))
   if self.linked:
    c.setFont('DB',7.5);c.drawRightString(w-36,h-28,'INDEX');c.linkRect('','navigation',(w-80,h-37,w-34,h-18),thickness=0)
   return h-47-used-16
  return h-85

def year(y):
 if y is None:return 'undated'
 s=str(int(y)) if float(y).is_integer() else f'{y:g}'
 return str(abs(int(y)))+' BCE' if y<0 else s

def source_refs(ids,linked=True):
 if linked:return b.source_refs(ids)
 return ' '.join('['+esc(i)+']' for i in ids)

def fit_text(s,w,font='D',size=9,maxlines=None):
 ls=lines_for(s,w,font,size)
 if maxlines and len(ls)>maxlines:
  ls=ls[:maxlines]
  while pdfmetrics.stringWidth(ls[-1]+'…',font,size)>w and ls[-1]:ls[-1]=ls[-1][:-1]
  ls[-1]+='…'
 return ls

def draw_lines(c,ls,x,y,font='D',size=9,leading=11,col=INK):
 c.setFillColor(HexColor(col));c.setFont(font,size)
 for line in ls:c.drawString(x,y,line);y-=leading
 return y

def arrow(c,x1,y1,x2,y2,col,openhead=False,size=5):
 ang=math.atan2(y2-y1,x2-x1);p=c.beginPath();p.moveTo(x2,y2)
 a=(x2-size*math.cos(ang-.5),y2-size*math.sin(ang-.5));z=(x2-size*math.cos(ang+.5),y2-size*math.sin(ang+.5))
 p.lineTo(*a)
 if not openhead:p.lineTo(*z);p.close()
 else:p.moveTo(x2,y2);p.lineTo(*z)
 c.setStrokeColor(HexColor(col));c.setFillColor(HexColor(col));c.drawPath(p,fill=not openhead,stroke=1)

def triangle(c,x,y,col,size=4,point='left',fill=False):
 dx=-1 if point=='left' else 1;p=c.beginPath();p.moveTo(x+dx*size,y);p.lineTo(x-dx*size,y+size);p.lineTo(x-dx*size,y-size);p.close()
 c.setStrokeColor(HexColor(col));c.setFillColor(HexColor(col));c.drawPath(p,fill=fill,stroke=1)

def compact_title(n):
 return n['title'].replace(' / ', ' · ')

def node_card(n,cw=225):
 title=fit_text(n['code']+' · '+PALETTE[n['tradition']][2]+' · '+compact_title(n),cw-18,'DB',8.7,1)
 author=fit_text(n['author'],cw-18,'D',7.9,1)
 date=fit_text(n['date_label'],cw-18,'DB',7.7,1)
 # Compact chart labels use visible ellipses; full records remain linked.
 h=37
 return {'w':cw,'h':h,'title':title,'author':author,'date':date}

def temporal_visible(n,lo,hi,mode='anchor'):
 t=n['temporal'];a=t['anchor']
 return a is not None and lo<=a<=hi

def layout_map(lo,hi,nodes,width,history=True,all_edges=False,undated=False):
 from timeline.integrated_geometry import layout
 return layout(D,lo,hi,nodes,width,node_card,history,undated)

def draw_map(doc,title,lo,hi,nodes,width=2400,history=True,key=None,undated=False,edge_labels=True,subtitle=''):
 L=layout_map(lo,hi,nodes,width,history,undated=undated);w,h=L['width'],L['height'];c=doc.c
 doc.new(title,(w,h),key);flip=lambda yy:h-yy;xx=L['xx']
 para(c,esc(subtitle or 'One chronological field: empire durations above; historical event rules through the texts. A vertical alignment supplies context, not a causal arrow.'),36,h-98,w-72,10.5)
 c.setFont('DB',10);c.setFillColor(HexColor(INK));c.drawString(36,h-133,f'{len(nodes)} entries · {len(L["edges"])} textual relations · {len(L["external"])} relations continue beyond this plate')
 span=hi-lo;tick=100 if span>1000 else 50 if span>350 else 25 if span>160 else 10
 ticks=range(math.ceil(lo/tick)*tick,math.floor(hi/tick)*tick+1,tick)
 for yr in ticks:
  if yr==0:continue
  x=xx(yr);c.setStrokeColor(HexColor('#E8EDEF'));c.setLineWidth(.5);c.line(x,flip(L['field_bottom']),x,h-168)
 # One common axis, touching the compact empire header and the shared text field.
 axis=flip(L['axis_y']);c.setStrokeColor(HexColor(INK));c.setLineWidth(1);c.line(L['left'],axis,w-40,axis)
 for yr in ticks:
  if yr==0:continue
  x=xx(yr);c.line(x,axis-4,x,axis+4);c.setFillColor(HexColor(MUTED));c.setFont('DB',9);c.drawCentredString(x,axis+7,year(yr));c.drawCentredString(x,98,year(yr))
 c.setFillColor(HexColor(MUTED));c.setFont('DB',8.3)
 c.drawString(36,h-156,'EMPIRES AND POLITICAL PERIODS · COMMON CALENDAR SCALE' if L['hist_draw'] else 'COMMON CALENDAR SCALE · CE / BCE')
 display=D['timeline_meta']['integrated_display']
 for item in L['hist_draw']:
  z=item['h'];x1,x2=item['x1'],item['x2'];y=flip(item['y']);ww=item['w'];lx=item['label_x']
  segs=z.get('segments') or [[z['start'],z['end']]]
  for seg in segs:
   a,bb=(seg[0],seg[1]) if isinstance(seg,list) else (seg['start'],seg['end'])
   if bb<lo or a>hi:continue
   sx=xx(max(lo,a));ex=xx(min(hi,bb));c.setFillColor(HexColor('#B4C5CC'));c.roundRect(sx,y-25,max(1,ex-sx),5,1.5,fill=1,stroke=0)
  if z.get('open_end') or z.get('end_is_chart_cutoff'):arrow(c,x2-10,y-22.5,x2,y-22.5,'#67899B',True,4)
  label=display['period_labels'].get(z['id'],z['label'])
  draw_lines(c,fit_text(label,ww,'DB',8.2,1),lx,y-8,'DB',8.2,9.5,INK)
  draw_lines(c,fit_text(z['date_label'],ww,'D',7.5,1),lx,y-18,'D',7.5,9,MUTED)
  if doc.linked:c.linkRect('','hist_'+z['id'],(min(x1,lx)-2,y-29,max(x2,lx+ww)+2,y+1),thickness=0)
 # Event rules extend through the same field that contains every text.
 for item in L['event_draw']:
  z=item['h'];a=z.get('year',z.get('start'));bb=z.get('end_year',a) or a
  x1=xx(max(lo,a));x2=xx(min(hi,bb));bottom=flip(L['field_bottom'])
  c.setStrokeColor(HexColor('#95603F'));c.setLineWidth(.7);c.setStrokeAlpha(.48)
  if bb!=a:
   c.setFillColor(HexColor('#B8865B'));c.setFillAlpha(.055);c.rect(x1,bottom,max(1,x2-x1),axis-bottom,fill=1,stroke=0);c.setFillAlpha(1)
   c.setDash([3,3]);c.line(x1,bottom,x1,axis);c.line(x2,bottom,x2,axis)
  else:
   c.setDash([2,4]);c.line(x1,bottom,x1,axis)
  c.setDash();c.setStrokeAlpha(1)
 # Relation curves run behind cards, from the source work toward its reception.
 edge_boxes=[]
 card_boxes=[(p['x'],flip(p['y'])-p['card']['h'],p['x']+p['card']['w'],flip(p['y'])) for p in L['placed']+L['event_draw']]
 for j,e in enumerate(L['edges']):
  sx,sy=L['positions'][e['source']];tx,ty=L['positions'][e['target']];sy=flip(sy);ty=flip(ty)
  col,dash,pw,tag,label=RELS.get(e['relation'],RELS['broad_influence'])
  qualified=e.get('confidence','') in ('qualified','proposed','claimed ancestry') or e['relation'] in ('hypothesis','claimed_lineage','broad_influence')
  c.setStrokeColor(HexColor(col));c.setStrokeAlpha(.32 if len(nodes)>120 else .45);c.setLineWidth(.6 if len(nodes)>120 else .85);c.setDash([2,4] if qualified else dash)
  if abs(sy-ty)<20:
   bump=25+min(110,abs(tx-sx)*.08)+(j%4)*7;cy1=sy+bump;cy2=ty+bump
  else:cy1=sy;cy2=ty
  cy1=min(cy1,flip(L['text_top']+8));cy2=min(cy2,flip(L['text_top']+8))
  dx=tx-sx;p=c.beginPath();p.moveTo(sx,sy);p.curveTo(sx+dx*.35,cy1,sx+dx*.65,cy2,tx,ty);c.drawPath(p)
  c.setStrokeAlpha(.7);c.setDash();arrow(c,sx+dx*.65,cy2,tx,ty,col,qualified,4)
  if e['relation']=='exchange':arrow(c,sx+dx*.35,cy1,sx,sy,col,True,4)
  if edge_labels:
   lab=e['id'].replace('_e','-')+' '+tag;tw=pdfmetrics.stringWidth(lab,'DB',6.8)
   found=False
   for t in [.5,.4,.6,.3,.7,.2,.8,.1,.9]:
    q=1-t;mx=q**3*sx+3*q*q*t*(sx+dx*.35)+3*q*t*t*(sx+dx*.65)+t**3*tx
    my=q**3*sy+3*q*q*t*cy1+3*q*t*t*cy2+t**3*ty
    for shift in [0,10,-10,20,-20,32,-32,46,-46]:
     rr=(mx-tw/2-2,my+shift-2,mx+tw/2+2,my+shift+8)
     if rr[0]<L['left']-30 or rr[2]>w-36 or rr[1]<112 or rr[3]>flip(L['text_top']):continue
     if not any(not(rr[2]<r[0]-2 or rr[0]>r[2]+2 or rr[3]<r[1]-2 or rr[1]>r[3]+2) for r in edge_boxes+card_boxes):found=True;break
    if found:break
   edge_boxes.append(rr);c.setFillAlpha(1);c.setFillColor(HexColor(PAPER));c.rect(rr[0],rr[1],rr[2]-rr[0],rr[3]-rr[1],fill=1,stroke=0);c.setFont('DB',6.8);c.setFillColor(HexColor(col));c.drawCentredString(mx,rr[1]+2,lab)
   if doc.linked:c.linkRect('','edge_'+e['id'],rr,thickness=0)
 c.setStrokeAlpha(1);c.setFillAlpha(1);c.setDash()
 # Historical labels occupy gaps among the works; no separate event row.
 for item in L['event_draw']:
  z=item['h'];x=item['x'];ax=item['anchor_x'];y=flip(item['y']);cc=item['card'];col='#895631'
  c.setFillColor(HexColor(PAPER));c.rect(x-2,y-cc['h'],cc['w']+4,cc['h'],fill=1,stroke=0)
  c.setStrokeColor(HexColor(col));c.setFillColor(HexColor(col));c.setLineWidth(.8)
  gy=y-6;p=c.beginPath();p.moveTo(ax,gy+3.2);p.lineTo(ax+3.2,gy);p.lineTo(ax,gy-3.2);p.lineTo(ax-3.2,gy);p.close();c.drawPath(p,fill=1,stroke=0);c.line(ax+4,gy,x,gy)
  draw_lines(c,fit_text(z['date_label'],cc['w']-10,'DB',8.2,1),x+5,y-10,'DB',8.2,10,col)
  label=display['event_labels'].get(z['id'],z['label'])
  draw_lines(c,fit_text(label,cc['w']-10,'D',8.2,2),x+5,y-21,'D',8.2,9.5,col)
  if doc.linked:c.linkRect('','hist_'+z['id'],(x-3,y-cc['h'],x+cc['w'],y+1),thickness=0)
 if any(p.get('undated') for p in L['placed']):
  y=flip(L['field_bottom']+20);c.setFont('DB',8.5);c.setFillColor(HexColor(MUTED));c.drawString(36,y,'UNDATED CONTEXTS · NOT ASSIGNED A POSITION ON THE YEAR AXIS')
 # Marks and labels use true time positions; labels may extend to the right.
 for item in L['placed']:
  n=item['n'];t=n['temporal'];x=item['x'];y=flip(item['y']);ax=item['anchor_x'];cc=item['card'];fill,col,code,lab=PALETTE[n['tradition']]
  gy=y-6
  if not item.get('undated'):
   if t['kind'] in ('range','context'):
    a=xx(max(lo,t['start']));bb=xx(min(hi,t['end']));c.setFillColor(HexColor(col));c.setFillAlpha(.2);c.rect(a,gy-3,max(1,bb-a),6,fill=1,stroke=0);c.setFillAlpha(1);c.setStrokeColor(HexColor(col));c.setLineWidth(1);c.line(a,gy-5,a,gy+5);c.line(bb,gy-5,bb,gy+5)
   elif t['kind']=='upper_bound':
    c.setStrokeColor(HexColor(col));c.setDash([2,2]);c.line(ax-28,gy,ax,gy);c.setDash();triangle(c,ax,gy,col,4,'left',False)
   elif t['kind']=='lower_bound':triangle(c,ax,gy,col,4,'right',False)
   elif t['kind']=='publication':
    c.setStrokeColor(HexColor(col));c.rect(ax-3,gy-3,6,6,fill=0,stroke=1)
   else:
    c.setStrokeColor(HexColor(col));c.setFillColor(HexColor(col));c.circle(ax,gy,3.3,fill=t['kind']=='exact',stroke=1)
   c.setStrokeColor(HexColor(col));c.setLineWidth(.6);c.line(ax+5,gy,x,gy)
  c.setFillColor(HexColor(PAPER));c.setStrokeColor(HexColor(col));c.setLineWidth(.65)
  c.setDash([3,2] if n.get('node_type')!='work' else [])
  c.roundRect(x,y-cc['h'],cc['w'],cc['h'],4,fill=1,stroke=1);c.setDash()
  yy=draw_lines(c,cc['title'],x+8,y-11,'DB',8.7,10,col)
  yy=draw_lines(c,cc['author'],x+8,yy,'D',7.9,9,INK)-1
  draw_lines(c,cc['date'],x+8,yy,'DB',7.7,9,col)
  if doc.linked:c.linkRect('','work_'+n['id'],(x,y-cc['h'],x+cc['w'],y),thickness=0)
 # Constant footnotes and relationship access.
 para(c,'<b>Dating:</b> filled dot = dated year; open dot = approximation; band = range or stages; left triangle = upper bound; square = publication witness. No midpoint is claimed as a composition date. Chart labels use ellipses; the linked catalogue gives full titles, authors and date qualifications.',36,76,w-72,8.3)
 para(c,'<b>Relations:</b> C commentary · G gloss · T translation/adaptation · U use · A author reference · X critique · R reported doctrine · S source testimony · E exchange · B broader link · ? hypothesis · L claimed lineage. Every relation remains in the evidence register.',36,61,w-72,8.3)
 doc.map_records.append(dict(key=key,title=title,page=doc.p,size=[w,h],range=[lo,hi],nodes=[n['id'] for n in nodes],edges=[e['id'] for e in L['edges']],external_edges=[e['id'] for e in L['external']],periods=[p['h']['id'] for p in L['hist_draw']],events=[p['h']['id'] for p in L['event_draw']],rulers=[],axis_y=L['axis_y'],text_top=L['text_top'],field_bottom=L['field_bottom']))
 return L

def cover(doc,brief=False):
 c=doc.c;doc.new(key='cover');w,h=A4
 c.setFillColor(HexColor(NAVY));c.rect(0,h-275,w,275,fill=1,stroke=0)
 c.setFillColor(HexColor('#B9D4DF'));c.setFont('DB',9.5);c.drawString(40,h-43,'INTEGRATED CHRONOLOGY · REVISION 2 · 28 OCTOBER 2026')
 c.setFillColor(white);c.setFont('DSB',34);c.drawString(40,h-110,'Texts in time')
 para(c,'Empires, events and scholarly works<br/>in one chronological field',40,h-145,w-80,18,color='#E5EFF3',leading=25)
 para(c,'Chronology · textual relations · evidence · interaction design',40,h-231,w-80,10.5,color='#E5EFF3')
 H=D['history'];y=h-310
 y-=para(c,f'<b>{len(D["nodes"])} catalogue entries · {len(D["edges"])} textual relations</b><br/>{len(D["timeline_meta"]["integrated_display"]["period_ids"])} political periods · {len(H["events"])} selected events · no individual reign rows',40,y,w-80,11)+20
 y-=para(c,'Compact empire and state bands sit directly above one shared time axis. Works and historical event labels are interleaved below it; event rules continue through the text field. Colors and codes distinguish intellectual traditions without separating them into tall panels.',40,y,w-80,11)+18
 y-=para(c,('<b>Overview edition.</b> A short route through the historical view and proposed website interaction. The companion full atlas retains all records, source notes and relationships.' if brief else '<b>Full reference edition.</b> Includes the complete chronological network, period enlargements, historical source register, website specification and every work/relationship record from the critical atlas.'),40,y,w-80,10.5)+20
 c.setFillColor(HexColor('#E8F0F4'));c.roundRect(40,y-100,w-80,100,6,fill=1,stroke=0)
 para(c,'<b>Read down a date, then follow a textual connection</b><br/>Empire durations, events and works share one calendar.<br/>A vertical event rule aligns a historical moment with the texts.<br/>An arrow between works states an evidenced textual relationship.',54,y-15,w-108,10.1)
 para(c,'Political history is selected for this corpus, not an exhaustive history of every Islamic region. Dates refer to texts or explicit bounds; author lifetimes remain separately recorded.',40,61,w-80,8.8,color=MUTED)

def method(doc):
 y=doc.new('How to read a historical timeline without inventing dates',A4,'timeline_method');c=doc.c;w,h=A4
 for head,txt in [
 ('One proportional axis','Time runs left to right. The main Islamic view covers 570–2026 CE; the ancient prelude extends to 600 BCE. Every panel states its range. The complete network retains the ancient material and all later textual links.'),
 ('A point is a stronger claim than a bound','152 entries use an upper-bound marker in this chronological view. A text labelled “before 1897” is not plotted as a work written in 1897. Its triangle marks a latest bound with an open direction into the past. No lower endpoint is invented.'),
 ('Ranges and multiple stages','Bands show the range recorded in the catalogue. They may cover an uncertain date, writing and revision, a multi-volume series or a contextual span. A band does not assert that writing continued throughout every intervening year.'),
 ('Three unplaced context entries','The Buddha narrative antecedents, ancient Iranian sages invoked in medieval claims, and undated Upaniṣadic source strata stay on an undated rail. The 1657 Persian translation is a reception witness, not the birth date of its Sanskrit sources.'),
 ('One field for history and scholarship','Empire and political-period bars are packed above the common axis. Event labels occupy gaps among the works, with vertical rules through the same field. Individual reigns and the ceremonial Cairo Abbasid office are omitted. The surviving spans are scoped political periods, not territorial borders; 2026 remains a chart cutoff.'),
 ('What a calendar position cannot establish','A latest bound may fall within a reign even when the work was written earlier. The graphic supplies context; patronage, teaching or causal influence needs independent evidence. All 286 textual relations retain their earlier type, scope and qualification.')]:
  y-=para(c,esc(head),36,y,w-72,11.2,bold=True)+4;y-=para(c,esc(b.tidy(txt)),36,y,w-72,9.6)+16
 y=doc.new('Symbols, colors and evidence',A4,'timeline_legend')
 examples=[('Dated','jurjani_mawaqif'),('Range / stages','avicenna_shifa'),('Latest bound','jilveh_shifa'),('Publication witness','javadi_rahiq'),('Undated context','upanishads_selection')]
 for title,ident in examples:
  n=NI[ident];y-=para(c,f'<b>{esc(title)}</b> · {esc(n["title"])}<br/>{esc(n["date_label"])}<br/>{esc(b.tidy(n["temporal"]["note"]))}',36,y,w-72,9.7)+16
 y-=para(c,'The same reception colors and printed codes are retained. A work’s textual family does not certify its author’s assent. “Independent” means a standalone work rather than a commentary.',36,y,w-72,9.7)+14
 for j,(stream,(fill,col,code,label)) in enumerate(PALETTE.items()):
  xx=36+(j%2)*(w-72)/2;yy=y-(j//2)*22
  c.setFillColor(HexColor(fill));c.setStrokeColor(HexColor(col));c.roundRect(xx,yy-11,11,11,2,fill=1,stroke=1)
  short=label.replace(' reception','').replace(' networks','').replace(' authored works','')
  c.setFillColor(HexColor(INK));c.setFont('DB',8);c.drawString(xx+17,yy-9,code)
  c.setFont('D',7.8);c.drawString(xx+48,yy-9,short)

def web_design(doc):
 items=[
 dict(title='The recommended entry view',text='Open with a historical overview and a small set of representative texts. Use compact empire/state bars directly above the shared text field. Interleave event callouts among the works and extend their date rules through the diagram. Omit individual reign rows. Keep a time brush or range control visible, and let the reader expand a century or search for a text. Reveal the complete 286-relation network when requested.'),
 dict(title='Three synchronized views',text='Timeline answers “when and alongside what?” Relations answers “what does this work draw on, and who responds to it?” Catalogue gives a searchable, accessible list. The same selected work, filters and evidence records persist when the view changes.'),
 dict(title='Click a work',text='Open a persistent side panel on desktop and an accessible below-map panel on a phone. Show Arabic and transliterated title, author and life dates, work date and its basis, genre, region, reception family, qualifications, edition/scale notes, sources, and incoming/outgoing relationships. Clicking the author lists that author’s works.'),
 dict(title='Click an arrow',text='Reveal the source work, receiving work, relation type, evidentiary confidence, scope note and citations. A commentary, criticism, author reference, source testimony and hypothesis remain distinct. The panel must explain the exact claim instead of showing only “influenced by.”'),
 dict(title='Click political context',text='Open the empire/period or event record with scoped dates, region, uncertainties and historical citations. Highlight the selected period’s span or the event’s vertical rule through the text field. Temporal overlap never becomes a textual influence edge. Selected context may be compared with the text, but no patronage is inferred from coincidence.'),
 dict(title='Zoom changes the amount of detail',text='At overview scale show representative titles or labelled clusters. At a regional/century scale reveal individual works. Once a work is selected, highlight its immediate sources and reception and allow a second-hop expansion. Make omitted/off-screen relations countable and accessible from the panel.'),
 dict(title='Keep the diagram stable',text='Use a fixed chronological axis and stable positions within the common field. Color and text codes distinguish reception families; they do not need separate vertical panels. Avoid a continually moving force layout. After selection, retain the current time window unless the user asks to fit the neighbourhood. Preserve selection and filter state in a shareable URL.'),
 dict(title='Mobile and keyboard access',text='Essential information is available on click/tap and keyboard focus, not hover alone. Provide comfortable touch targets, zoom buttons, clear filter labels, a reset control and a table alternative. A visible relationship list supplies an accessible alternative to selecting a thin line.',sources=['WEB03','WEB04'])]
 v.block_pages(doc,'Website interaction: a readable entrance to the full archive',items,'website_interaction')
 items=[
 dict(title='One research dataset, several presentations',text='Keep stable work, author, relation and historical-context IDs in one versioned JSON dataset. Generate the PDF, map, catalogue and work detail pages from those records. Retain dates as structured uncertainty-aware objects alongside the original scholarly label.'),
 dict(title='Recommended rendering',text='For this corpus, an SVG timeline is sufficient and keeps text crisp and interactions inspectable. D3 linear scales and zoom/brush behaviour are a suitable production option; the supplied demonstration implements the core interactions without external dependencies. The recommendation is an engineering judgement, not a benchmark claim.',sources=['WEB01','WEB02']),
 dict(title='Keep scholarly content in ordinary pages too',text='A work URL should render its complete record even without the diagram. Proposed routes: /atlas/timeline, /atlas/relations, /atlas/works/<stable-id>, /atlas/authors/<stable-id>, and /atlas/relations/<edge-id>. The public site should publish only the records and sources intended for readers.'),
 dict(title='Separate data fields from display decisions',text='A temporal anchor positions a label; it is not an asserted composition year. Preserve minimum/maximum bounds, date basis, original AH or SH wording, recensions and publication witnesses. Keep intellectual membership multi-valued even when a map uses one principal color.'),
 dict(title='Filters must not silently rewrite the argument',text='Filtering hides records from a view, never deletes their evidence. Show the number of hidden relations and provide “view all connections.” Keep uncertainty controls visible: confirmed formal relations, qualified broader links, hypotheses and claimed ancestries are different selections.'),
 dict(title='Acceptance checks for integration',text='All 295 entries and 286 relationships must resolve by ID. Arabic and transliteration search must find equivalent targets. Upper bounds retain their symbols. Touch and keyboard users can open the same details. Back/forward restores the selected record. PDF and site cite the same source record.'),
 dict(title='Prototype and production scope',text='The accompanying interactive diagram demonstrates the proposed content and navigation. Production integration should adopt the site’s existing reader chrome, permanent URLs and publication workflow. The diagram’s role is to lead into the research record and primary-text reading, not to replace them.')]
 v.block_pages(doc,'Website implementation: preserve the research while changing the view',items,'website_implementation')

def history_register(doc):
 entries=[]
 for group in ['periods','events']:
  for x in D['history'][group]:
   if group=='periods' and x['id'] not in D['timeline_meta']['integrated_display']['period_ids']:continue
   entries.append((group,x))
 entries.sort(key=lambda q:(q[1].get('year',q[1].get('start',0)),q[1]['id']))
 def txt(pair):
  typ,z=pair;fields=f'<b>{esc(z["id"])} · {esc(z["label"])}</b><br/><b>{esc(z["date_label"])}</b> · {esc(z.get("region",""))}<br/>'
  if z.get('role'):fields+='<b>Role:</b> '+esc(z['role'])+'<br/>'
  fields+=esc(z.get('note',''))
  if z.get('open_end') or z.get('end_is_chart_cutoff'):fields+='<br/>2026 is the diagram’s present cutoff, not an asserted historical endpoint.'
  return b.tidy(fields)+'<br/>'+source_refs(z.get('sources',[]),doc.linked)
 def render(pair,x,y,w,h):
  doc.c.bookmarkHorizontal('hist_'+pair[1]['id'],0,y);doc.history_pages[pair[1]['id']]=doc.p
  used=para(doc.c,txt(pair),x,y,w,9);doc.c.setStrokeColor(HexColor(RULE));doc.c.line(x,y-used-10,x+w,y-used-10)
 b.entry_flow(doc,entries,render,lambda z,w:pheight(txt(z),w,9)+20,'Empires and events: scoped dates and sources','history_register',cols=2,size=landscape(A4))

def dating_register(doc):
 items=[]
 for n in D['nodes']:
  if n['id'] in ['kumijani_nur','javadi_rahiq','upanishads_selection','buddha_narrative_anchor','iranian_sages_claim','hilli_nihaya','abduh_basair','isfahani_abwab'] or (n['id'].startswith('sadra_') and n['temporal']['kind']=='upper_bound'):
   items.append(dict(title=n['code']+' · '+n['title'],text=n['temporal']['note']))
 v.block_pages(doc,'Specific chronological display decisions',items,'temporal_decisions')

def author_index(doc):
 def txt(a):
  works=' · '.join(f'<link href="#work_{i}" color="#006CB0">{NI[i]["code"]}</link>' for i in a['works'])
  return f'<b>{esc(a["name"])}</b><br/>{esc(" / ".join(a["date_labels"]))}<br/>{works}'
 b.entry_flow(doc,D['author_index'],lambda a,x,y,w,h:para(doc.c,txt(a),x,y,w,8.6),lambda a,w:pheight(txt(a),w,8.6)+12,'Authors: life dates and catalogue works','author_index',cols=2,size=landscape(A4))

PERIODS=[(-600,570,'Ancient and late antique antecedents',True),(570,1050,'Early Islam, translation and theological formation',True),(1050,1250,'Avicennan continuations, kalām and new syntheses',True),(1250,1400,'Mongol-era networks and the major summae',True),(1400,1550,'Commentaries, regional courts and early modern transitions',True),(1550,1725,'Ottoman, Safavid and Mughal intellectual worlds',True),(1725,1900,'Later continuations, criticism and new political settings',True),(1900,2026,'Modern teaching, theological projects and political transitions',True)]

def build():
 full=Doc(OUT/'Islamic_Intellectual_Timeline.pdf',True);cover(full);method(full)
 # All works and all textual relations in one real-time diagram.
 draw_map(full,'The complete chronological network: 600 BCE–2026 CE',-600,2026,D['nodes'],11500,True,'complete_timeline',True,True,'All 295 entries and 286 relationships are retained. Three undated contexts occupy a separate rail. Use the following period enlargements and linked records for close reading.')
 for lo,hi,title,hist in PERIODS:
  ns=[n for n in D['nodes'] if temporal_visible(n,lo,hi)]
  draw_map(full,title,lo,hi,ns,4000 if len(ns)>45 else 3200,hist,'period_'+str(lo).replace('-','b'),False,True)
 dating_register(full);web_design(full);history_register(full)
 ref=copy.deepcopy(D);ref['sources']=D['sources']+D['history']['sources']+TECH_SOURCES
 v.catalogue(full,ref,NI);v.evidence_register(full,ref,NI);v.source_register(full,ref)
 v.block_pages(full,'Critical audit carried forward from the genealogical atlas',D['audit'],'critical_audit')
 v.prior_audit(full,D,NI);v.block_pages(full,'Further research qualifications',D['notes'],'qualifications')
 author_index(full);v.navigation(full,D,NI);full.save()
 brief=Doc(OUT/'Islamic_Timeline_Overview.pdf',False);cover(brief,True);method(brief)
 ns=[n for n in D['nodes'] if n['featured']]
 draw_map(brief,'Integrated overview: empires, events and selected texts',570,2026,ns,3300,True,'overview',False,True,'38 representative entries in one chronological field with empire bands and event rules. The complete reference edition retains every catalogue entry and textual relationship.')
 for lo,hi,title,hist in PERIODS:
  # These pages are still comprehensive for their anchor window, not a new selective history.
  ns=[n for n in D['nodes'] if temporal_visible(n,lo,hi)]
  draw_map(brief,title,lo,hi,ns,4000 if len(ns)>45 else 3200,hist,'period_'+str(lo).replace('-','b'),False,True)
 web_design(brief)
 # Source links in the brief are external; all source IDs still resolve in the full atlas.
 # The website-design block renderer creates source bookmarks, so supply its four records.
 v.source_register(brief,{'sources':TECH_SOURCES})
 brief.save()
 audit={'entries':len(D['nodes']),'relations':len(D['edges']),'history_archived':{k:len(D['history'][k]) for k in ['periods','rulers','events','sources']},'history_displayed':{'periods':len(D['timeline_meta']['integrated_display']['period_ids']),'rulers':0,'events':len(D['history']['events'])},'full_pages':full.p,'overview_pages':brief.p,'maps':full.map_records,'toc':full.toc,'work_pages':full.work_pages,'edge_pages':full.edge_pages,'history_pages':full.history_pages,'authors':len(D['author_index'])}
 (TMP/'build_audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2))
 print(json.dumps({k:v for k,v in audit.items() if k not in ['maps','toc','work_pages','edge_pages','history_pages']},indent=2))

if __name__=='__main__':build()
