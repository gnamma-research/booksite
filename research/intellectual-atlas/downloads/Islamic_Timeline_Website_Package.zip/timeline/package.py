"""Package the current integrated diagram, source register and implementation."""
from pathlib import Path
import json, zipfile
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'output/timeline';OUT.mkdir(parents=True,exist_ok=True)
files={
 'timeline/README.txt':'README.txt',
 'output/timeline/Islamic_Intellectual_Timeline.html':'index.html',
 'timeline/timeline_data.json':'timeline/timeline_data.json',
 'timeline/history_early.json':'timeline/history_early.json',
 'timeline/history_late.json':'timeline/history_late.json',
 'timeline/integrated_display.json':'timeline/integrated_display.json',
 'timeline/integrated_geometry.py':'timeline/integrated_geometry.py',
 'timeline/build_data.py':'timeline/build_data.py',
 'timeline/build_pdf.py':'timeline/build_pdf.py',
 'timeline/build_interactive.py':'timeline/build_interactive.py',
 'timeline/interactive_template.html':'timeline/interactive_template.html',
 'timeline/interactive_design_notes.txt':'timeline/interactive_design_notes.txt',
 'timeline/validate_revision.py':'timeline/validate_revision.py',
 'timeline/package.py':'timeline/package.py',
 'research_v2/merged.json':'research_v2/merged.json',
 'build_kalam_atlas.py':'build_kalam_atlas.py',
 'build_kalam_atlas_v2.py':'build_kalam_atlas_v2.py',
 'tmp/timeline/build_audit.json':'validation/build_audit.json',
 'tmp/timeline/revision_validation.json':'validation/revision_validation.json',
 'timeline/integrated_validation.json':'validation/interactive_validation.json'
}
target=OUT/'Islamic_Timeline_Website_Package.zip'
with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED) as z:
 for source,dest in files.items():
  path=ROOT/source
  if not path.exists():
   if source=='timeline/README.txt':path=ROOT/'README.txt'
   elif source.startswith('tmp/timeline/'):path=ROOT/'validation'/Path(source).name
   elif source=='timeline/integrated_validation.json':path=ROOT/'validation/interactive_validation.json'
   elif source=='output/timeline/Islamic_Intellectual_Timeline.html':path=ROOT/'index.html'
  z.write(path,dest)
with zipfile.ZipFile(target) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(files)
print(json.dumps({'file':str(target),'files':len(files),'bytes':target.stat().st_size},indent=2))
