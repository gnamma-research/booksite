Open Open_Atlas.html. The 404-entry, 377-relationship map and evidence register work offline. Links to the Tajrid reader, other research branches, source repositories and historical PDFs require an internet connection. The current sourcebook static download is supplied separately.

31 October UI update: return links preserve reader filters and comparison selection.
