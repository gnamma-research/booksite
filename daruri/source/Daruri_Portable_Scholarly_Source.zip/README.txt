Daruri — portable digital source archive
========================================
This is NOT the offline Gnamma reader ZIP. It is the machine-readable source
from which HTML, PDF and future digital editions can be typeset.

The authoritative release data lives in the canonical reader payload.
- daruri-source.json: complete unmodified canonical book object, including
  scholarly notes, term metadata, applications and source relationships.
- daruri-passages.jsonl: 414 aligned original Arabic, editorial vowelled
  Arabic and English translation passages with permanent R/paragraph IDs.
- daruri-parallel.html: a standalone, offline, semantic HTML reading file.
- daruri-arabic.html, daruri-arabic-vowelled.html, daruri-english.html.
- daruri.tei.xml: research-oriented TEI P5 parallel text and note mapping.
- shamela-import-arabic.txt: straightforward UTF-8 Arabic text.
- shamela-import-vowelled.txt: Arabic with editorial vocalization.
- shamela-import-arabic.html: simple Arabic-only HTML, for legacy import.
- daruri-notes.json: all 625 canonical scholarly/source note records.
- scholarly-data/full-headwords.json: 153 historical term dossiers and
  157 selected full historical dictionary articles.
- scholarly-data/{quran,hadith,backmatter}-source-notes.json: original full
  source reference records, qualifications, references and withheld candidates.
- daruri-colophon.json: the later copyist’s TWO separate paragraphs.
  Colophon material also appears clearly separated in HTML, TEI and TXT.
- manifest.json: file checksums, counts and provenance.

Source numbering:
- R001–R258 are Gnamma editorial reading-unit references, not Ibn Rushd's
  own numbered chapter headings.
- The source has 46 recorded Arabic headings, which are distinguished from
  the 258 descriptive English editorial section labels.
- Arabic vocalization and English translation are editorial.
- The later copyist's colophon is separate from Ibn Rushd's 258 units.
- This archive is an editorial work; do not describe it as a manuscript
  diplomatic transcription or an independently established original text.

Shamela:
The older official Shamela import instructions document TXT and HTML
imports. These files are import-ready *candidates* for its legacy importer;
actual Shamela v4/Windows version compatibility is NOT independently
certified here. A .bok file is a native application/database exchange
format and must NOT be created by renaming TXT or HTML.
Use Shamela's Services > Import Files and test a copy in your version.
Plain TXT will not preserve the full rich bilingual scholarly apparatus.
The JSON and TEI documents are the authoritative archival exports.

Offline:
Open the standalone HTML files directly; no web server, sign-in or network
is required. No personal Reading Desk notes, private highlights, cookies,
account data or passwords are present.

Rights and source attribution:
Ibn Rushd (d. 1198) is the historical author. The Gnamma Arabic reading text
uses Jamal al-Din al-Alawi's printed 1994 edition with selected comparison
to the Arabic edition and apparatus published by Ziad Bou Akl in 2015.
The Escorial manuscript has NOT been newly collated by Gnamma.
The modern editors' introductions, translations and apparatus are NOT
licensed for independent republication by this download.

The historical dictionary authors and works are individually identified in
scholarly-data/full-headwords.json, including source-by-source digital witness
URLs. Among the witnesses are OpenITI, Shamela, Wikisource, Arabic Lexicon
and Arabic-keyboard.info. The historical wording is distinct from modern
digital transcription and publication rights. Comply with source-specific
reuse terms and attribution obligations; this ZIP does not waive them.

English translations, Arabic vowel marks, editorial section titles and notes
are Gnamma editorial work. Public distribution of this source snapshot does
not grant a blanket open licence to reproduce every component, especially
modern transcriptions or third-party editorial material. Cite the Gnamma
release and original source witnesses, and review each component's provenance
before redistribution or modification. This is a technical source export,
not a certified independent manuscript edition or legal rights opinion.

Checksum:
Use manifest.json to confirm ZIP entries have not been corrupted or changed.
